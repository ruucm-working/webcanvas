(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var check = Package.check.check;
var Match = Package.check.Match;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var __coffeescriptShare, FileCollection;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/gridFS.coffee.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
share.defaultChunkSize = 2 * 1024 * 1024 - 1024;                                                                       // 7
share.defaultRoot = 'fs';                                                                                              // 8
share.resumableBase = '/_resumable';                                                                                   // 10
                                                                                                                       //
share.insert_func = function (file, chunkSize) {                                                                       // 12
  var id, ref, ref1, ref2, ref3, subFile;                                                                              // 13
                                                                                                                       //
  if (file == null) {                                                                                                  // 9
    file = {};                                                                                                         // 12
  }                                                                                                                    // 11
                                                                                                                       //
  try {                                                                                                                // 13
    id = new Mongo.ObjectID("" + file._id);                                                                            // 14
  } catch (error) {                                                                                                    // 13
    id = new Mongo.ObjectID();                                                                                         // 16
  }                                                                                                                    // 16
                                                                                                                       //
  subFile = {};                                                                                                        // 17
  subFile._id = id;                                                                                                    // 18
  subFile.length = 0;                                                                                                  // 19
  subFile.md5 = 'd41d8cd98f00b204e9800998ecf8427e';                                                                    // 20
  subFile.uploadDate = new Date();                                                                                     // 21
  subFile.chunkSize = chunkSize;                                                                                       // 22
  subFile.filename = (ref = file.filename) != null ? ref : '';                                                         // 23
  subFile.metadata = (ref1 = file.metadata) != null ? ref1 : {};                                                       // 24
  subFile.aliases = (ref2 = file.aliases) != null ? ref2 : [];                                                         // 25
  subFile.contentType = (ref3 = file.contentType) != null ? ref3 : 'application/octet-stream';                         // 26
  return subFile;                                                                                                      // 27
};                                                                                                                     // 12
                                                                                                                       //
share.reject_file_modifier = function (modifier) {                                                                     // 29
  var forbidden, required;                                                                                             // 31
  forbidden = Match.OneOf(Match.ObjectIncluding({                                                                      // 31
    _id: Match.Any                                                                                                     // 32
  }), Match.ObjectIncluding({                                                                                          // 32
    length: Match.Any                                                                                                  // 33
  }), Match.ObjectIncluding({                                                                                          // 33
    chunkSize: Match.Any                                                                                               // 34
  }), Match.ObjectIncluding({                                                                                          // 34
    md5: Match.Any                                                                                                     // 35
  }), Match.ObjectIncluding({                                                                                          // 35
    uploadDate: Match.Any                                                                                              // 36
  }));                                                                                                                 // 36
  required = Match.OneOf(Match.ObjectIncluding({                                                                       // 39
    _id: Match.Any                                                                                                     // 40
  }), Match.ObjectIncluding({                                                                                          // 40
    length: Match.Any                                                                                                  // 41
  }), Match.ObjectIncluding({                                                                                          // 41
    chunkSize: Match.Any                                                                                               // 42
  }), Match.ObjectIncluding({                                                                                          // 42
    md5: Match.Any                                                                                                     // 43
  }), Match.ObjectIncluding({                                                                                          // 43
    uploadDate: Match.Any                                                                                              // 44
  }), Match.ObjectIncluding({                                                                                          // 44
    metadata: Match.Any                                                                                                // 45
  }), Match.ObjectIncluding({                                                                                          // 45
    aliases: Match.Any                                                                                                 // 46
  }), Match.ObjectIncluding({                                                                                          // 46
    filename: Match.Any                                                                                                // 47
  }), Match.ObjectIncluding({                                                                                          // 47
    contentType: Match.Any                                                                                             // 48
  }));                                                                                                                 // 48
  return Match.test(modifier, Match.OneOf(Match.ObjectIncluding({                                                      // 51
    $set: forbidden                                                                                                    // 52
  }), Match.ObjectIncluding({                                                                                          // 52
    $unset: required                                                                                                   // 53
  }), Match.ObjectIncluding({                                                                                          // 53
    $inc: forbidden                                                                                                    // 54
  }), Match.ObjectIncluding({                                                                                          // 54
    $mul: forbidden                                                                                                    // 55
  }), Match.ObjectIncluding({                                                                                          // 55
    $bit: forbidden                                                                                                    // 56
  }), Match.ObjectIncluding({                                                                                          // 56
    $min: forbidden                                                                                                    // 57
  }), Match.ObjectIncluding({                                                                                          // 57
    $max: forbidden                                                                                                    // 58
  }), Match.ObjectIncluding({                                                                                          // 58
    $rename: required                                                                                                  // 59
  }), Match.ObjectIncluding({                                                                                          // 59
    $currentDate: forbidden                                                                                            // 60
  }), Match.Where(function (pat) {                                                                                     // 60
    return !Match.test(pat, Match.OneOf(Match.ObjectIncluding({                                                        // 62
      $inc: Match.Any                                                                                                  // 63
    }), Match.ObjectIncluding({                                                                                        // 63
      $set: Match.Any                                                                                                  // 64
    }), Match.ObjectIncluding({                                                                                        // 64
      $unset: Match.Any                                                                                                // 65
    }), Match.ObjectIncluding({                                                                                        // 65
      $addToSet: Match.Any                                                                                             // 66
    }), Match.ObjectIncluding({                                                                                        // 66
      $pop: Match.Any                                                                                                  // 67
    }), Match.ObjectIncluding({                                                                                        // 67
      $pullAll: Match.Any                                                                                              // 68
    }), Match.ObjectIncluding({                                                                                        // 68
      $pull: Match.Any                                                                                                 // 69
    }), Match.ObjectIncluding({                                                                                        // 69
      $pushAll: Match.Any                                                                                              // 70
    }), Match.ObjectIncluding({                                                                                        // 70
      $push: Match.Any                                                                                                 // 71
    }), Match.ObjectIncluding({                                                                                        // 71
      $bit: Match.Any                                                                                                  // 72
    })));                                                                                                              // 72
  })));                                                                                                                // 61
};                                                                                                                     // 29
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/server_shared.coffee.js                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var through2;                                                                                                          // 7
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 7
  through2 = Npm.require('through2');                                                                                  // 9
  share.defaultResponseHeaders = {                                                                                     // 11
    'Content-Type': 'text/plain'                                                                                       // 12
  };                                                                                                                   // 12
                                                                                                                       //
  share.check_allow_deny = function (type, userId, file, fields) {                                                     // 14
    var checkRules, result;                                                                                            // 16
                                                                                                                       //
    checkRules = function (rules) {                                                                                    // 16
      var func, i, len, ref, res;                                                                                      // 17
      res = false;                                                                                                     // 17
      ref = rules[type];                                                                                               // 18
                                                                                                                       //
      for (i = 0, len = ref.length; i < len; i++) {                                                                    // 18
        func = ref[i];                                                                                                 // 15
                                                                                                                       //
        if (!res) {                                                                                                    // 16
          res = func(userId, file, fields);                                                                            // 19
        }                                                                                                              // 18
      }                                                                                                                // 18
                                                                                                                       //
      return res;                                                                                                      // 20
    };                                                                                                                 // 16
                                                                                                                       //
    result = !checkRules(this.denys) && checkRules(this.allows);                                                       // 22
    return result;                                                                                                     // 23
  };                                                                                                                   // 14
                                                                                                                       //
  share.bind_env = function (func) {                                                                                   // 25
    if (func != null) {                                                                                                // 26
      return Meteor.bindEnvironment(func, function (err) {                                                             // 27
        throw err;                                                                                                     // 27
      });                                                                                                              // 27
    } else {                                                                                                           // 26
      return func;                                                                                                     // 29
    }                                                                                                                  // 32
  };                                                                                                                   // 25
                                                                                                                       //
  share.safeObjectID = function (s) {                                                                                  // 31
    if (s != null ? s.match(/^[0-9a-f]{24}$/i) : void 0) {                                                             // 32
      return new Mongo.ObjectID(s);                                                                                    // 36
    } else {                                                                                                           // 32
      return null;                                                                                                     // 38
    }                                                                                                                  // 39
  };                                                                                                                   // 31
                                                                                                                       //
  share.streamChunker = function (size) {                                                                              // 37
    var makeFuncs;                                                                                                     // 38
                                                                                                                       //
    if (size == null) {                                                                                                // 43
      size = share.defaultChunkSize;                                                                                   // 37
    }                                                                                                                  // 45
                                                                                                                       //
    makeFuncs = function (size) {                                                                                      // 38
      var bufferList, flush, total, transform;                                                                         // 39
      bufferList = [new Buffer(0)];                                                                                    // 39
      total = 0;                                                                                                       // 40
                                                                                                                       //
      flush = function (cb) {                                                                                          // 41
        var lastBuffer, newBuffer, outSize, outputBuffer;                                                              // 42
        outSize = total > size ? size : total;                                                                         // 42
                                                                                                                       //
        if (outSize > 0) {                                                                                             // 43
          outputBuffer = Buffer.concat(bufferList, outSize);                                                           // 44
          this.push(outputBuffer);                                                                                     // 45
          total -= outSize;                                                                                            // 46
        }                                                                                                              // 57
                                                                                                                       //
        lastBuffer = bufferList.pop();                                                                                 // 47
        newBuffer = lastBuffer.slice(lastBuffer.length - total);                                                       // 48
        bufferList = [newBuffer];                                                                                      // 49
                                                                                                                       //
        if (total < size) {                                                                                            // 50
          return cb();                                                                                                 // 62
        } else {                                                                                                       // 50
          return flush.bind(this)(cb);                                                                                 // 64
        }                                                                                                              // 65
      };                                                                                                               // 41
                                                                                                                       //
      transform = function (chunk, enc, cb) {                                                                          // 54
        bufferList.push(chunk);                                                                                        // 55
        total += chunk.length;                                                                                         // 56
                                                                                                                       //
        if (total < size) {                                                                                            // 57
          return cb();                                                                                                 // 71
        } else {                                                                                                       // 57
          return flush.bind(this)(cb);                                                                                 // 73
        }                                                                                                              // 74
      };                                                                                                               // 54
                                                                                                                       //
      return [transform, flush];                                                                                       // 61
    };                                                                                                                 // 38
                                                                                                                       //
    return through2.apply(this, makeFuncs(size));                                                                      // 62
  };                                                                                                                   // 37
}                                                                                                                      // 80
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/gridFS_server.coffee.js                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };
                                                                                                                       //
var dicer,                                                                                                             // 7
    express,                                                                                                           // 7
    fs,                                                                                                                // 7
    grid,                                                                                                              // 7
    gridLocks,                                                                                                         // 7
    mongodb,                                                                                                           // 7
    path,                                                                                                              // 7
    extend = function (child, parent) {                                                                                // 7
  for (var key in meteorBabelHelpers.sanitizeForInObject(parent)) {                                                    // 7
    if (hasProp.call(parent, key)) child[key] = parent[key];                                                           // 7
  }                                                                                                                    // 7
                                                                                                                       //
  function ctor() {                                                                                                    // 7
    this.constructor = child;                                                                                          // 7
  }                                                                                                                    // 7
                                                                                                                       //
  ctor.prototype = parent.prototype;                                                                                   // 7
  child.prototype = new ctor();                                                                                        // 7
  child.__super__ = parent.prototype;                                                                                  // 7
  return child;                                                                                                        // 7
},                                                                                                                     // 7
    hasProp = {}.hasOwnProperty;                                                                                       // 7
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 7
  mongodb = Npm.require('mongodb');                                                                                    // 9
  grid = Npm.require('gridfs-locking-stream');                                                                         // 10
  gridLocks = Npm.require('gridfs-locks');                                                                             // 11
  fs = Npm.require('fs');                                                                                              // 12
  path = Npm.require('path');                                                                                          // 13
  dicer = Npm.require('dicer');                                                                                        // 14
  express = Npm.require('express');                                                                                    // 15
                                                                                                                       //
  FileCollection = function (superClass) {                                                                             // 17
    extend(FileCollection, superClass);                                                                                // 14
                                                                                                                       //
    function FileCollection(root, options) {                                                                           // 19
      var indexOptions, ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7, ref8, self;                                     // 20
      this.root = root != null ? root : share.defaultRoot;                                                             // 19
                                                                                                                       //
      if (options == null) {                                                                                           // 19
        options = {};                                                                                                  // 19
      }                                                                                                                // 21
                                                                                                                       //
      if (!(this instanceof FileCollection)) {                                                                         // 20
        return new FileCollection(this.root, options);                                                                 // 21
      }                                                                                                                // 24
                                                                                                                       //
      if (!(this instanceof Mongo.Collection)) {                                                                       // 23
        throw new Meteor.Error('The global definition of Mongo.Collection has changed since the file-collection package was loaded. Please ensure that any packages that redefine Mongo.Collection are loaded before file-collection.');
      }                                                                                                                // 27
                                                                                                                       //
      if (Mongo.Collection !== Mongo.Collection.prototype.constructor) {                                               // 26
        throw new Meteor.Error('The global definition of Mongo.Collection has been patched by another package, and the prototype constructor has been left in an inconsistent state. Please see this link for a workaround: https://github.com/vsivsi/meteor-file-sample-app/issues/2#issuecomment-120780592');
      }                                                                                                                // 30
                                                                                                                       //
      if (_typeof(this.root) === 'object') {                                                                           // 29
        options = this.root;                                                                                           // 30
        this.root = share.defaultRoot;                                                                                 // 31
      }                                                                                                                // 34
                                                                                                                       //
      this.chunkSize = (ref = options.chunkSize) != null ? ref : share.defaultChunkSize;                               // 33
      this.db = Meteor.wrapAsync(mongodb.MongoClient.connect)(process.env.MONGO_URL, {});                              // 35
      this.lockOptions = {                                                                                             // 37
        timeOut: (ref1 = (ref2 = options.locks) != null ? ref2.timeOut : void 0) != null ? ref1 : 360,                 // 38
        lockExpiration: (ref3 = (ref4 = options.locks) != null ? ref4.lockExpiration : void 0) != null ? ref3 : 90,    // 39
        pollingInterval: (ref5 = (ref6 = options.locks) != null ? ref6.pollingInterval : void 0) != null ? ref5 : 5    // 40
      };                                                                                                               // 38
      this.locks = gridLocks.LockCollection(this.db, {                                                                 // 42
        root: this.root,                                                                                               // 43
        timeOut: this.lockOptions.timeOut,                                                                             // 44
        lockExpiration: this.lockOptions.lockExpiration,                                                               // 45
        pollingInterval: this.lockOptions.pollingInterval                                                              // 46
      });                                                                                                              // 43
      this.gfs = new grid(this.db, mongodb, this.root);                                                                // 48
      this.baseURL = (ref7 = options.baseURL) != null ? ref7 : "/gridfs/" + this.root;                                 // 50
                                                                                                                       //
      if (options.resumable || options.http) {                                                                         // 53
        share.setupHttpAccess.bind(this)(options);                                                                     // 54
      }                                                                                                                // 52
                                                                                                                       //
      this.allows = {                                                                                                  // 57
        read: [],                                                                                                      // 57
        insert: [],                                                                                                    // 57
        write: [],                                                                                                     // 57
        remove: []                                                                                                     // 57
      };                                                                                                               // 57
      this.denys = {                                                                                                   // 58
        read: [],                                                                                                      // 58
        insert: [],                                                                                                    // 58
        write: [],                                                                                                     // 58
        remove: []                                                                                                     // 58
      };                                                                                                               // 58
                                                                                                                       //
      FileCollection.__super__.constructor.call(this, this.root + '.files', {                                          // 61
        idGeneration: 'MONGO'                                                                                          // 61
      });                                                                                                              // 61
                                                                                                                       //
      if (options.resumable) {                                                                                         // 64
        indexOptions = {};                                                                                             // 65
                                                                                                                       //
        if (typeof options.resumableIndexName === 'string') {                                                          // 66
          indexOptions.name = options.resumableIndexName;                                                              // 67
        }                                                                                                              // 72
                                                                                                                       //
        this.db.collection(this.root + ".files").ensureIndex({                                                         // 69
          'metadata._Resumable.resumableIdentifier': 1,                                                                // 70
          'metadata._Resumable.resumableChunkNumber': 1,                                                               // 71
          length: 1                                                                                                    // 72
        }, indexOptions);                                                                                              // 69
      }                                                                                                                // 78
                                                                                                                       //
      this.maxUploadSize = (ref8 = options.maxUploadSize) != null ? ref8 : -1;                                         // 75
                                                                                                                       //
      FileCollection.__super__.allow.bind(this)({                                                                      // 87
        insert: function (_this) {                                                                                     // 90
          return function (userId, file) {                                                                             // 82
            return true;                                                                                               // 83
          };                                                                                                           // 90
        }(this),                                                                                                       // 90
        remove: function (_this) {                                                                                     // 91
          return function (userId, file) {                                                                             // 87
            return true;                                                                                               // 88
          };                                                                                                           // 91
        }(this)                                                                                                        // 91
      });                                                                                                              // 90
                                                                                                                       //
      FileCollection.__super__.deny.bind(this)({                                                                       // 93
        insert: function (_this) {                                                                                     // 95
          return function (userId, file) {                                                                             // 94
            check(file, {                                                                                              // 98
              _id: Mongo.ObjectID,                                                                                     // 99
              length: Match.Where(function (x) {                                                                       // 100
                check(x, Match.Integer);                                                                               // 101
                return x === 0;                                                                                        // 99
              }),                                                                                                      // 100
              md5: Match.Where(function (x) {                                                                          // 103
                check(x, String);                                                                                      // 104
                return x === 'd41d8cd98f00b204e9800998ecf8427e';                                                       // 103
              }),                                                                                                      // 103
              uploadDate: Date,                                                                                        // 106
              chunkSize: Match.Where(function (x) {                                                                    // 107
                check(x, Match.Integer);                                                                               // 108
                return x === _this.chunkSize;                                                                          // 108
              }),                                                                                                      // 107
              filename: String,                                                                                        // 110
              contentType: String,                                                                                     // 111
              aliases: [String],                                                                                       // 112
              metadata: Object                                                                                         // 113
            });                                                                                                        // 99
                                                                                                                       //
            if (file.chunkSize !== _this.chunkSize) {                                                                  // 116
              console.warn("Invalid chunksize");                                                                       // 117
              return true;                                                                                             // 118
            }                                                                                                          // 118
                                                                                                                       //
            if (share.check_allow_deny.bind(_this)('insert', userId, file)) {                                          // 121
              return false;                                                                                            // 122
            }                                                                                                          // 121
                                                                                                                       //
            return true;                                                                                               // 124
          };                                                                                                           // 95
        }(this),                                                                                                       // 95
        update: function (_this) {                                                                                     // 126
          return function (userId, file, fields) {                                                                     // 126
            return true;                                                                                               // 132
          };                                                                                                           // 126
        }(this),                                                                                                       // 126
        remove: function (_this) {                                                                                     // 134
          return function (userId, file) {                                                                             // 131
            return true;                                                                                               // 137
          };                                                                                                           // 134
        }(this)                                                                                                        // 134
      });                                                                                                              // 95
                                                                                                                       //
      self = this;                                                                                                     // 139
                                                                                                                       //
      Meteor.server.method_handlers[this._prefix + "remove"] = function (selector) {                                   // 142
        var cursor, file;                                                                                              // 144
        check(selector, Object);                                                                                       // 144
                                                                                                                       //
        if (!LocalCollection._selectorIsIdPerhapsAsObject(selector)) {                                                 // 146
          throw new Meteor.Error(403, "Not permitted. Untrusted code may only remove documents by ID.");               // 147
        }                                                                                                              // 142
                                                                                                                       //
        cursor = self.find(selector);                                                                                  // 149
                                                                                                                       //
        if (cursor.count() > 1) {                                                                                      // 151
          throw new Meteor.Error(500, "Remote remove selector targets multiple files.\nSee https://github.com/vsivsi/meteor-file-collection/issues/152#issuecomment-278824127");
        }                                                                                                              // 146
                                                                                                                       //
        file = cursor.fetch()[0];                                                                                      // 154
                                                                                                                       //
        if (file) {                                                                                                    // 156
          if (share.check_allow_deny.bind(self)('remove', this.userId, file)) {                                        // 157
            return self.remove(file);                                                                                  // 158
          } else {                                                                                                     // 157
            throw new Meteor.Error(403, "Access denied");                                                              // 160
          }                                                                                                            // 156
        } else {                                                                                                       // 156
          return 0;                                                                                                    // 162
        }                                                                                                              // 156
      };                                                                                                               // 142
    }                                                                                                                  // 19
                                                                                                                       //
    FileCollection.prototype.allow = function (allowOptions) {                                                         // 160
      var func, results, type;                                                                                         // 166
      results = [];                                                                                                    // 166
                                                                                                                       //
      for (type in meteorBabelHelpers.sanitizeForInObject(allowOptions)) {                                             // 163
        func = allowOptions[type];                                                                                     // 164
                                                                                                                       //
        if (!(type in this.allows)) {                                                                                  // 167
          throw new Meteor.Error("Unrecognized allow rule type '" + type + "'.");                                      // 168
        }                                                                                                              // 167
                                                                                                                       //
        if (typeof func !== 'function') {                                                                              // 169
          throw new Meteor.Error("Allow rule " + type + " must be a valid function.");                                 // 170
        }                                                                                                              // 170
                                                                                                                       //
        results.push(this.allows[type].push(func));                                                                    // 171
      }                                                                                                                // 166
                                                                                                                       //
      return results;                                                                                                  // 173
    };                                                                                                                 // 165
                                                                                                                       //
    FileCollection.prototype.deny = function (denyOptions) {                                                           // 176
      var func, results, type;                                                                                         // 175
      results = [];                                                                                                    // 175
                                                                                                                       //
      for (type in meteorBabelHelpers.sanitizeForInObject(denyOptions)) {                                              // 179
        func = denyOptions[type];                                                                                      // 180
                                                                                                                       //
        if (!(type in this.denys)) {                                                                                   // 176
          throw new Meteor.Error("Unrecognized deny rule type '" + type + "'.");                                       // 177
        }                                                                                                              // 183
                                                                                                                       //
        if (typeof func !== 'function') {                                                                              // 178
          throw new Meteor.Error("Deny rule " + type + " must be a valid function.");                                  // 179
        }                                                                                                              // 186
                                                                                                                       //
        results.push(this.denys[type].push(func));                                                                     // 187
      }                                                                                                                // 175
                                                                                                                       //
      return results;                                                                                                  // 189
    };                                                                                                                 // 174
                                                                                                                       //
    FileCollection.prototype.insert = function (file, callback) {                                                      // 192
      if (file == null) {                                                                                              // 193
        file = {};                                                                                                     // 182
      }                                                                                                                // 195
                                                                                                                       //
      if (callback == null) {                                                                                          // 196
        callback = void 0;                                                                                             // 182
      }                                                                                                                // 198
                                                                                                                       //
      file = share.insert_func(file, this.chunkSize);                                                                  // 183
      return FileCollection.__super__.insert.call(this, file, callback);                                               // 200
    };                                                                                                                 // 182
                                                                                                                       //
    FileCollection.prototype.update = function (selector, modifier, options, callback) {                               // 203
      var err;                                                                                                         // 192
                                                                                                                       //
      if (options == null) {                                                                                           // 205
        options = {};                                                                                                  // 191
      }                                                                                                                // 207
                                                                                                                       //
      if (callback == null) {                                                                                          // 208
        callback = void 0;                                                                                             // 191
      }                                                                                                                // 210
                                                                                                                       //
      if (callback == null && typeof options === 'function') {                                                         // 192
        callback = options;                                                                                            // 193
        options = {};                                                                                                  // 194
      }                                                                                                                // 214
                                                                                                                       //
      if (options.upsert != null) {                                                                                    // 196
        err = new Meteor.Error("Update does not support the upsert option");                                           // 197
                                                                                                                       //
        if (callback != null) {                                                                                        // 198
          return callback(err);                                                                                        // 199
        } else {                                                                                                       // 198
          throw err;                                                                                                   // 201
        }                                                                                                              // 196
      }                                                                                                                // 222
                                                                                                                       //
      if (share.reject_file_modifier(modifier) && !options.force) {                                                    // 203
        err = new Meteor.Error("Modifying gridFS read-only document elements is a very bad idea!");                    // 204
                                                                                                                       //
        if (callback != null) {                                                                                        // 205
          return callback(err);                                                                                        // 206
        } else {                                                                                                       // 205
          throw err;                                                                                                   // 208
        }                                                                                                              // 203
      } else {                                                                                                         // 203
        return FileCollection.__super__.update.call(this, selector, modifier, options, callback);                      // 231
      }                                                                                                                // 232
    };                                                                                                                 // 191
                                                                                                                       //
    FileCollection.prototype.upsert = function (selector, modifier, options, callback) {                               // 235
      var err;                                                                                                         // 213
                                                                                                                       //
      if (options == null) {                                                                                           // 237
        options = {};                                                                                                  // 212
      }                                                                                                                // 239
                                                                                                                       //
      if (callback == null) {                                                                                          // 240
        callback = void 0;                                                                                             // 212
      }                                                                                                                // 242
                                                                                                                       //
      if (callback == null && typeof options === 'function') {                                                         // 213
        callback = options;                                                                                            // 214
      }                                                                                                                // 245
                                                                                                                       //
      err = new Meteor.Error("File Collections do not support 'upsert'");                                              // 215
                                                                                                                       //
      if (callback != null) {                                                                                          // 216
        return callback(err);                                                                                          // 248
      } else {                                                                                                         // 216
        throw err;                                                                                                     // 219
      }                                                                                                                // 251
    };                                                                                                                 // 212
                                                                                                                       //
    FileCollection.prototype.upsertStream = function (file, options, callback) {                                       // 254
      var cbCalled, found, mods, writeStream;                                                                          // 222
                                                                                                                       //
      if (options == null) {                                                                                           // 256
        options = {};                                                                                                  // 221
      }                                                                                                                // 258
                                                                                                                       //
      if (callback == null) {                                                                                          // 259
        callback = void 0;                                                                                             // 221
      }                                                                                                                // 261
                                                                                                                       //
      if (callback == null && typeof options === 'function') {                                                         // 222
        callback = options;                                                                                            // 223
        options = {};                                                                                                  // 224
      }                                                                                                                // 265
                                                                                                                       //
      callback = share.bind_env(callback);                                                                             // 225
      cbCalled = false;                                                                                                // 226
      mods = {};                                                                                                       // 227
                                                                                                                       //
      if (file.filename != null) {                                                                                     // 228
        mods.filename = file.filename;                                                                                 // 228
      }                                                                                                                // 271
                                                                                                                       //
      if (file.aliases != null) {                                                                                      // 229
        mods.aliases = file.aliases;                                                                                   // 229
      }                                                                                                                // 274
                                                                                                                       //
      if (file.contentType != null) {                                                                                  // 230
        mods.contentType = file.contentType;                                                                           // 230
      }                                                                                                                // 277
                                                                                                                       //
      if (file.metadata != null) {                                                                                     // 231
        mods.metadata = file.metadata;                                                                                 // 231
      }                                                                                                                // 280
                                                                                                                       //
      if (options.autoRenewLock == null) {                                                                             // 281
        options.autoRenewLock = true;                                                                                  // 233
      }                                                                                                                // 283
                                                                                                                       //
      if (options.mode === 'w+') {                                                                                     // 235
        throw new Meteor.Error("The ability to append file data in upsertStream() was removed in version 1.0.0");      // 236
      }                                                                                                                // 286
                                                                                                                       //
      if (file._id) {                                                                                                  // 239
        found = this.findOne({                                                                                         // 240
          _id: file._id                                                                                                // 240
        });                                                                                                            // 240
      }                                                                                                                // 291
                                                                                                                       //
      if (!(file._id && found)) {                                                                                      // 242
        file._id = this.insert(mods);                                                                                  // 243
      } else if (Object.keys(mods).length > 0) {                                                                       // 242
        this.update({                                                                                                  // 245
          _id: file._id                                                                                                // 245
        }, {                                                                                                           // 245
          $set: mods                                                                                                   // 245
        });                                                                                                            // 245
      }                                                                                                                // 300
                                                                                                                       //
      writeStream = Meteor.wrapAsync(this.gfs.createWriteStream.bind(this.gfs))({                                      // 247
        root: this.root,                                                                                               // 248
        _id: mongodb.ObjectID("" + file._id),                                                                          // 249
        mode: 'w',                                                                                                     // 250
        timeOut: this.lockOptions.timeOut,                                                                             // 251
        lockExpiration: this.lockOptions.lockExpiration,                                                               // 252
        pollingInterval: this.lockOptions.pollingInterval                                                              // 253
      });                                                                                                              // 248
                                                                                                                       //
      if (writeStream) {                                                                                               // 255
        if (options.autoRenewLock) {                                                                                   // 257
          writeStream.on('expires-soon', function (_this) {                                                            // 258
            return function () {                                                                                       // 312
              return writeStream.renewLock(function (e, d) {                                                           // 313
                if (e || !d) {                                                                                         // 260
                  return console.warn("Automatic Write Lock Renewal Failed: " + file._id, e);                          // 315
                }                                                                                                      // 316
              });                                                                                                      // 259
            };                                                                                                         // 258
          }(this));                                                                                                    // 258
        }                                                                                                              // 320
                                                                                                                       //
        if (callback != null) {                                                                                        // 263
          writeStream.on('close', function (retFile) {                                                                 // 264
            if (retFile) {                                                                                             // 265
              retFile._id = new Mongo.ObjectID(retFile._id.toHexString());                                             // 266
              return callback(null, retFile);                                                                          // 325
            }                                                                                                          // 326
          });                                                                                                          // 264
          writeStream.on('error', function (err) {                                                                     // 268
            return callback(err);                                                                                      // 329
          });                                                                                                          // 268
        }                                                                                                              // 331
                                                                                                                       //
        return writeStream;                                                                                            // 271
      }                                                                                                                // 333
                                                                                                                       //
      return null;                                                                                                     // 273
    };                                                                                                                 // 221
                                                                                                                       //
    FileCollection.prototype.findOneStream = function (selector, options, callback) {                                  // 337
      var file, opts, range, readStream, ref, ref1, ref2, ref3;                                                        // 276
                                                                                                                       //
      if (options == null) {                                                                                           // 339
        options = {};                                                                                                  // 275
      }                                                                                                                // 341
                                                                                                                       //
      if (callback == null) {                                                                                          // 342
        callback = void 0;                                                                                             // 275
      }                                                                                                                // 344
                                                                                                                       //
      if (callback == null && typeof options === 'function') {                                                         // 276
        callback = options;                                                                                            // 277
        options = {};                                                                                                  // 278
      }                                                                                                                // 348
                                                                                                                       //
      callback = share.bind_env(callback);                                                                             // 280
      opts = {};                                                                                                       // 281
                                                                                                                       //
      if (options.sort != null) {                                                                                      // 282
        opts.sort = options.sort;                                                                                      // 282
      }                                                                                                                // 353
                                                                                                                       //
      if (options.skip != null) {                                                                                      // 283
        opts.skip = options.skip;                                                                                      // 283
      }                                                                                                                // 356
                                                                                                                       //
      file = this.findOne(selector, opts);                                                                             // 284
                                                                                                                       //
      if (file) {                                                                                                      // 286
        if (options.autoRenewLock == null) {                                                                           // 359
          options.autoRenewLock = true;                                                                                // 287
        }                                                                                                              // 361
                                                                                                                       //
        range = {                                                                                                      // 290
          start: (ref = (ref1 = options.range) != null ? ref1.start : void 0) != null ? ref : 0,                       // 291
          end: (ref2 = (ref3 = options.range) != null ? ref3.end : void 0) != null ? ref2 : file.length - 1            // 292
        };                                                                                                             // 291
        readStream = Meteor.wrapAsync(this.gfs.createReadStream.bind(this.gfs))({                                      // 294
          root: this.root,                                                                                             // 295
          _id: mongodb.ObjectID("" + file._id),                                                                        // 296
          timeOut: this.lockOptions.timeOut,                                                                           // 297
          lockExpiration: this.lockOptions.lockExpiration,                                                             // 298
          pollingInterval: this.lockOptions.pollingInterval,                                                           // 299
          range: {                                                                                                     // 300
            startPos: range.start,                                                                                     // 301
            endPos: range.end                                                                                          // 302
          }                                                                                                            // 301
        });                                                                                                            // 295
                                                                                                                       //
        if (readStream) {                                                                                              // 304
          if (options.autoRenewLock) {                                                                                 // 305
            readStream.on('expires-soon', function (_this) {                                                           // 306
              return function () {                                                                                     // 380
                return readStream.renewLock(function (e, d) {                                                          // 381
                  if (e || !d) {                                                                                       // 308
                    return console.warn("Automatic Read Lock Renewal Failed: " + file._id, e);                         // 383
                  }                                                                                                    // 384
                });                                                                                                    // 307
              };                                                                                                       // 306
            }(this));                                                                                                  // 306
          }                                                                                                            // 388
                                                                                                                       //
          if (callback != null) {                                                                                      // 311
            readStream.on('close', function () {                                                                       // 312
              return callback(null, file);                                                                             // 391
            });                                                                                                        // 312
            readStream.on('error', function (err) {                                                                    // 314
              return callback(err);                                                                                    // 394
            });                                                                                                        // 314
          }                                                                                                            // 396
                                                                                                                       //
          return readStream;                                                                                           // 316
        }                                                                                                              // 286
      }                                                                                                                // 399
                                                                                                                       //
      return null;                                                                                                     // 318
    };                                                                                                                 // 275
                                                                                                                       //
    FileCollection.prototype.remove = function (selector, callback) {                                                  // 403
      var err, ret;                                                                                                    // 321
                                                                                                                       //
      if (callback == null) {                                                                                          // 405
        callback = void 0;                                                                                             // 320
      }                                                                                                                // 407
                                                                                                                       //
      callback = share.bind_env(callback);                                                                             // 321
                                                                                                                       //
      if (selector != null) {                                                                                          // 322
        ret = 0;                                                                                                       // 323
        this.find(selector).forEach(function (_this) {                                                                 // 324
          return function (file) {                                                                                     // 412
            var res;                                                                                                   // 325
            res = Meteor.wrapAsync(_this.gfs.remove.bind(_this.gfs))({                                                 // 325
              _id: mongodb.ObjectID("" + file._id),                                                                    // 326
              root: _this.root,                                                                                        // 327
              timeOut: _this.lockOptions.timeOut,                                                                      // 328
              lockExpiration: _this.lockOptions.lockExpiration,                                                        // 329
              pollingInterval: _this.lockOptions.pollingInterval                                                       // 330
            });                                                                                                        // 326
            return ret += res ? 1 : 0;                                                                                 // 421
          };                                                                                                           // 324
        }(this));                                                                                                      // 324
        callback != null && callback(null, ret);                                                                       // 332
        return ret;                                                                                                    // 333
      } else {                                                                                                         // 322
        err = new Meteor.Error("Remove with an empty selector is not supported");                                      // 335
                                                                                                                       //
        if (callback != null) {                                                                                        // 336
          callback(err);                                                                                               // 337
        } else {                                                                                                       // 336
          throw err;                                                                                                   // 340
        }                                                                                                              // 322
      }                                                                                                                // 433
    };                                                                                                                 // 320
                                                                                                                       //
    FileCollection.prototype.importFile = function (filePath, file, callback) {                                        // 436
      var readStream, writeStream;                                                                                     // 343
      callback = share.bind_env(callback);                                                                             // 343
      filePath = path.normalize(filePath);                                                                             // 344
                                                                                                                       //
      if (file == null) {                                                                                              // 440
        file = {};                                                                                                     // 345
      }                                                                                                                // 442
                                                                                                                       //
      if (file.filename == null) {                                                                                     // 443
        file.filename = path.basename(filePath);                                                                       // 346
      }                                                                                                                // 445
                                                                                                                       //
      readStream = fs.createReadStream(filePath);                                                                      // 347
      readStream.on('error', share.bind_env(callback));                                                                // 348
      writeStream = this.upsertStream(file);                                                                           // 349
      return readStream.pipe(share.streamChunker(this.chunkSize)).pipe(writeStream).on('close', share.bind_env(function (d) {
        return callback(null, d);                                                                                      // 450
      })).on('error', share.bind_env(callback));                                                                       // 351
    };                                                                                                                 // 342
                                                                                                                       //
    FileCollection.prototype.exportFile = function (selector, filePath, callback) {                                    // 454
      var readStream, writeStream;                                                                                     // 355
      callback = share.bind_env(callback);                                                                             // 355
      filePath = path.normalize(filePath);                                                                             // 356
      readStream = this.findOneStream(selector);                                                                       // 357
      writeStream = fs.createWriteStream(filePath);                                                                    // 358
      return readStream.pipe(writeStream).on('finish', share.bind_env(callback)).on('error', share.bind_env(callback));
    };                                                                                                                 // 354
                                                                                                                       //
    return FileCollection;                                                                                             // 463
  }(Mongo.Collection);                                                                                                 // 465
}                                                                                                                      // 466
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/resumable_server.coffee.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var async, check_order, dicer, express, grid, gridLocks, mongodb, resumable_get_handler, resumable_get_lookup, resumable_post_handler, resumable_post_lookup;
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 7
  express = Npm.require('express');                                                                                    // 9
  mongodb = Npm.require('mongodb');                                                                                    // 10
  grid = Npm.require('gridfs-locking-stream');                                                                         // 11
  gridLocks = Npm.require('gridfs-locks');                                                                             // 12
  dicer = Npm.require('dicer');                                                                                        // 13
  async = Npm.require('async');                                                                                        // 14
                                                                                                                       //
  check_order = function (file, callback) {                                                                            // 19
    var fileId, lock;                                                                                                  // 20
    fileId = mongodb.ObjectID("" + file.metadata._Resumable.resumableIdentifier);                                      // 20
    lock = gridLocks.Lock(fileId, this.locks, {}).obtainWriteLock();                                                   // 21
    lock.on('locked', function (_this) {                                                                               // 22
      return function () {                                                                                             // 15
        var cursor, files;                                                                                             // 24
        files = _this.db.collection(_this.root + ".files");                                                            // 24
        cursor = files.find({                                                                                          // 26
          'metadata._Resumable.resumableIdentifier': file.metadata._Resumable.resumableIdentifier,                     // 28
          length: {                                                                                                    // 29
            $ne: 0                                                                                                     // 30
          }                                                                                                            // 30
        }, {                                                                                                           // 27
          fields: {                                                                                                    // 33
            length: 1,                                                                                                 // 34
            metadata: 1                                                                                                // 35
          },                                                                                                           // 34
          sort: {                                                                                                      // 36
            'metadata._Resumable.resumableChunkNumber': 1                                                              // 37
          }                                                                                                            // 37
        });                                                                                                            // 32
        return cursor.count(function (err, count) {                                                                    // 32
          var chunks;                                                                                                  // 42
                                                                                                                       //
          if (err) {                                                                                                   // 42
            lock.releaseLock();                                                                                        // 43
            return callback(err);                                                                                      // 44
          }                                                                                                            // 37
                                                                                                                       //
          if (!(count >= 1)) {                                                                                         // 46
            cursor.close();                                                                                            // 47
            lock.releaseLock();                                                                                        // 48
            return callback();                                                                                         // 49
          }                                                                                                            // 42
                                                                                                                       //
          if (count !== file.metadata._Resumable.resumableTotalChunks) {                                               // 51
            cursor.close();                                                                                            // 52
            lock.releaseLock();                                                                                        // 53
            return callback();                                                                                         // 54
          }                                                                                                            // 47
                                                                                                                       //
          chunks = _this.db.collection(_this.root + ".chunks");                                                        // 57
          cursor.batchSize(file.metadata._Resumable.resumableTotalChunks + 1);                                         // 59
          return cursor.toArray(function (err, parts) {                                                                // 50
            if (err) {                                                                                                 // 63
              lock.releaseLock();                                                                                      // 64
              return callback(err);                                                                                    // 65
            }                                                                                                          // 54
                                                                                                                       //
            return async.eachLimit(parts, 5, function (part, cb) {                                                     // 55
              var partId, partlock;                                                                                    // 69
                                                                                                                       //
              if (err) {                                                                                               // 69
                console.error("Error from cursor.next()", err);                                                        // 70
                cb(err);                                                                                               // 71
              }                                                                                                        // 60
                                                                                                                       //
              if (!part) {                                                                                             // 72
                return cb(new Meteor.Error("Received null part"));                                                     // 72
              }                                                                                                        // 63
                                                                                                                       //
              partId = mongodb.ObjectID("" + part._id);                                                                // 73
              partlock = gridLocks.Lock(partId, _this.locks, {}).obtainWriteLock();                                    // 74
              partlock.on('locked', function () {                                                                      // 75
                return async.series([function (cb) {                                                                   // 67
                  return chunks.update({                                                                               // 69
                    files_id: partId,                                                                                  // 78
                    n: 0                                                                                               // 78
                  }, {                                                                                                 // 78
                    $set: {                                                                                            // 79
                      files_id: fileId,                                                                                // 79
                      n: part.metadata._Resumable.resumableChunkNumber - 1                                             // 79
                    }                                                                                                  // 79
                  }, cb);                                                                                              // 79
                }, function (cb) {                                                                                     // 76
                  return files.remove({                                                                                // 79
                    _id: partId                                                                                        // 82
                  }, cb);                                                                                              // 82
                }], function (err, res) {                                                                              // 76
                  if (err) {                                                                                           // 85
                    return cb(err);                                                                                    // 85
                  }                                                                                                    // 86
                                                                                                                       //
                  if (part.metadata._Resumable.resumableChunkNumber !== part.metadata._Resumable.resumableTotalChunks) {
                    partlock.removeLock();                                                                             // 87
                    return cb();                                                                                       // 89
                  } else {                                                                                             // 86
                    return chunks.update({                                                                             // 91
                      files_id: partId,                                                                                // 91
                      n: 1                                                                                             // 91
                    }, {                                                                                               // 91
                      $set: {                                                                                          // 92
                        files_id: fileId,                                                                              // 92
                        n: part.metadata._Resumable.resumableChunkNumber                                               // 92
                      }                                                                                                // 92
                    }, function (err, res) {                                                                           // 92
                      partlock.removeLock();                                                                           // 94
                                                                                                                       //
                      if (err) {                                                                                       // 95
                        return cb(err);                                                                                // 95
                      }                                                                                                // 103
                                                                                                                       //
                      return cb();                                                                                     // 104
                    });                                                                                                // 91
                  }                                                                                                    // 106
                });                                                                                                    // 76
              });                                                                                                      // 75
              partlock.on('timed-out', function () {                                                                   // 97
                return cb(new Meteor.Error('Partlock timed out!'));                                                    // 110
              });                                                                                                      // 97
              partlock.on('expired', function () {                                                                     // 98
                return cb(new Meteor.Error('Partlock expired!'));                                                      // 113
              });                                                                                                      // 98
              return partlock.on('error', function (err) {                                                             // 115
                console.error("Error obtaining partlock " + part._id, err);                                            // 100
                return cb(err);                                                                                        // 117
              });                                                                                                      // 99
            }, function (err) {                                                                                        // 67
              var md5Command;                                                                                          // 103
                                                                                                                       //
              if (err) {                                                                                               // 103
                lock.releaseLock();                                                                                    // 104
                return callback(err);                                                                                  // 105
              }                                                                                                        // 124
                                                                                                                       //
              md5Command = {                                                                                           // 107
                filemd5: fileId,                                                                                       // 108
                root: "" + _this.root                                                                                  // 109
              };                                                                                                       // 108
              return _this.db.command(md5Command, function (err, results) {                                            // 129
                if (err) {                                                                                             // 112
                  lock.releaseLock();                                                                                  // 113
                  return callback(err);                                                                                // 114
                }                                                                                                      // 133
                                                                                                                       //
                return files.update({                                                                                  // 134
                  _id: fileId                                                                                          // 116
                }, {                                                                                                   // 116
                  $set: {                                                                                              // 116
                    length: file.metadata._Resumable.resumableTotalSize,                                               // 116
                    md5: results.md5                                                                                   // 116
                  }                                                                                                    // 116
                }, function (_this) {                                                                                  // 116
                  return function (err, res) {                                                                         // 142
                    lock.releaseLock();                                                                                // 118
                    return callback(err);                                                                              // 144
                  };                                                                                                   // 117
                }(this));                                                                                              // 117
              });                                                                                                      // 111
            });                                                                                                        // 67
          });                                                                                                          // 61
        });                                                                                                            // 41
      };                                                                                                               // 22
    }(this));                                                                                                          // 22
    lock.on('expires-soon', function () {                                                                              // 121
      return lock.renewLock().once('renewed', function (ld) {                                                          // 154
        if (!ld) {                                                                                                     // 123
          return console.warn("Resumable upload lock renewal failed!");                                                // 156
        }                                                                                                              // 157
      });                                                                                                              // 122
    });                                                                                                                // 121
    lock.on('expired', function () {                                                                                   // 125
      return callback(new Meteor.Error("File Lock expired"));                                                          // 161
    });                                                                                                                // 125
    lock.on('timed-out', function () {                                                                                 // 126
      return callback(new Meteor.Error("File Lock timed out"));                                                        // 164
    });                                                                                                                // 126
    return lock.on('error', function (err) {                                                                           // 166
      return callback(err);                                                                                            // 167
    });                                                                                                                // 127
  };                                                                                                                   // 19
                                                                                                                       //
  resumable_post_lookup = function (params, query, multipart) {                                                        // 131
    var ref;                                                                                                           // 132
    return {                                                                                                           // 132
      _id: share.safeObjectID(multipart != null ? (ref = multipart.params) != null ? ref.resumableIdentifier : void 0 : void 0)
    };                                                                                                                 // 132
  };                                                                                                                   // 131
                                                                                                                       //
  resumable_post_handler = function (req, res, next) {                                                                 // 134
    var chunkQuery, findResult, ref, ref1, resumable, writeStream;                                                     // 137
                                                                                                                       //
    if (!((ref = req.multipart) != null ? (ref1 = ref.params) != null ? ref1.resumableIdentifier : void 0 : void 0)) {
      console.error("Missing resumable.js multipart information");                                                     // 138
      res.writeHead(501, share.defaultResponseHeaders);                                                                // 139
      res.end();                                                                                                       // 140
      return;                                                                                                          // 141
    }                                                                                                                  // 183
                                                                                                                       //
    resumable = req.multipart.params;                                                                                  // 143
    resumable.resumableTotalSize = parseInt(resumable.resumableTotalSize);                                             // 144
    resumable.resumableTotalChunks = parseInt(resumable.resumableTotalChunks);                                         // 145
    resumable.resumableChunkNumber = parseInt(resumable.resumableChunkNumber);                                         // 146
    resumable.resumableChunkSize = parseInt(resumable.resumableChunkSize);                                             // 147
    resumable.resumableCurrentChunkSize = parseInt(resumable.resumableCurrentChunkSize);                               // 148
                                                                                                                       //
    if (req.maxUploadSize > 0) {                                                                                       // 150
      if (!(resumable.resumableTotalSize <= req.maxUploadSize)) {                                                      // 151
        res.writeHead(413, share.defaultResponseHeaders);                                                              // 152
        res.end();                                                                                                     // 153
        return;                                                                                                        // 154
      }                                                                                                                // 150
    }                                                                                                                  // 196
                                                                                                                       //
    if (!(req.gridFS.chunkSize === resumable.resumableChunkSize && resumable.resumableChunkNumber <= resumable.resumableTotalChunks && resumable.resumableTotalSize / resumable.resumableChunkSize <= resumable.resumableTotalChunks + 1 && resumable.resumableCurrentChunkSize === resumable.resumableChunkSize || resumable.resumableChunkNumber === resumable.resumableTotalChunks && resumable.resumableCurrentChunkSize < 2 * resumable.resumableChunkSize)) {
      res.writeHead(501, share.defaultResponseHeaders);                                                                // 164
      res.end();                                                                                                       // 165
      return;                                                                                                          // 166
    }                                                                                                                  // 201
                                                                                                                       //
    chunkQuery = {                                                                                                     // 168
      length: resumable.resumableCurrentChunkSize,                                                                     // 169
      'metadata._Resumable.resumableIdentifier': resumable.resumableIdentifier,                                        // 170
      'metadata._Resumable.resumableChunkNumber': resumable.resumableChunkNumber                                       // 171
    };                                                                                                                 // 169
    findResult = this.findOne(chunkQuery, {                                                                            // 174
      fields: {                                                                                                        // 174
        _id: 1                                                                                                         // 174
      }                                                                                                                // 174
    });                                                                                                                // 174
                                                                                                                       //
    if (findResult) {                                                                                                  // 176
      res.writeHead(200, share.defaultResponseHeaders);                                                                // 179
      return res.end();                                                                                                // 214
    } else {                                                                                                           // 176
      req.gridFS.metadata._Resumable = resumable;                                                                      // 183
      writeStream = this.upsertStream({                                                                                // 184
        filename: "_Resumable_" + resumable.resumableIdentifier + "_" + resumable.resumableChunkNumber + "_" + resumable.resumableTotalChunks,
        metadata: req.gridFS.metadata                                                                                  // 186
      });                                                                                                              // 185
                                                                                                                       //
      if (!writeStream) {                                                                                              // 188
        res.writeHead(404, share.defaultResponseHeaders);                                                              // 189
        res.end();                                                                                                     // 190
        return;                                                                                                        // 191
      }                                                                                                                // 225
                                                                                                                       //
      return req.multipart.fileStream.pipe(share.streamChunker(this.chunkSize)).pipe(writeStream).on('close', share.bind_env(function (_this) {
        return function (retFile) {                                                                                    // 227
          if (retFile) {                                                                                               // 195
            return check_order.bind(_this)(req.gridFS, function (err) {                                                // 229
              if (err) {                                                                                               // 198
                console.error("Error reassembling chunks of resumable.js upload", err);                                // 199
                res.writeHead(500, share.defaultResponseHeaders);                                                      // 200
              } else {                                                                                                 // 198
                res.writeHead(200, share.defaultResponseHeaders);                                                      // 202
              }                                                                                                        // 235
                                                                                                                       //
              return res.end();                                                                                        // 236
            });                                                                                                        // 197
          } else {                                                                                                     // 195
            console.error("Missing retFile on pipe close");                                                            // 206
            res.writeHead(500, share.defaultResponseHeaders);                                                          // 207
            return res.end();                                                                                          // 241
          }                                                                                                            // 242
        };                                                                                                             // 194
      }(this))).on('error', share.bind_env(function (_this) {                                                          // 194
        return function (err) {                                                                                        // 245
          console.error("Piping Error!", err);                                                                         // 212
          res.writeHead(500, share.defaultResponseHeaders);                                                            // 213
          return res.end();                                                                                            // 248
        };                                                                                                             // 211
      }(this)));                                                                                                       // 211
    }                                                                                                                  // 251
  };                                                                                                                   // 134
                                                                                                                       //
  resumable_get_lookup = function (params, query) {                                                                    // 216
    var q;                                                                                                             // 217
    q = {                                                                                                              // 217
      _id: share.safeObjectID(query.resumableIdentifier)                                                               // 217
    };                                                                                                                 // 217
    return q;                                                                                                          // 218
  };                                                                                                                   // 216
                                                                                                                       //
  resumable_get_handler = function (req, res, next) {                                                                  // 223
    var chunkQuery, query, result;                                                                                     // 224
    query = req.query;                                                                                                 // 224
    chunkQuery = {                                                                                                     // 225
      $or: [{                                                                                                          // 226
        _id: share.safeObjectID(query.resumableIdentifier),                                                            // 228
        length: parseInt(query.resumableTotalSize)                                                                     // 229
      }, {                                                                                                             // 227
        length: parseInt(query.resumableCurrentChunkSize),                                                             // 232
        'metadata._Resumable.resumableIdentifier': query.resumableIdentifier,                                          // 233
        'metadata._Resumable.resumableChunkNumber': parseInt(query.resumableChunkNumber)                               // 234
      }]                                                                                                               // 231
    };                                                                                                                 // 226
    result = this.findOne(chunkQuery, {                                                                                // 238
      fields: {                                                                                                        // 238
        _id: 1                                                                                                         // 238
      }                                                                                                                // 238
    });                                                                                                                // 238
                                                                                                                       //
    if (result) {                                                                                                      // 239
      res.writeHead(200, share.defaultResponseHeaders);                                                                // 241
    } else {                                                                                                           // 239
      res.writeHead(204, share.defaultResponseHeaders);                                                                // 244
    }                                                                                                                  // 284
                                                                                                                       //
    return res.end();                                                                                                  // 285
  };                                                                                                                   // 223
                                                                                                                       //
  share.resumablePaths = [{                                                                                            // 249
    method: 'head',                                                                                                    // 251
    path: share.resumableBase,                                                                                         // 252
    lookup: resumable_get_lookup,                                                                                      // 253
    handler: resumable_get_handler                                                                                     // 254
  }, {                                                                                                                 // 250
    method: 'post',                                                                                                    // 257
    path: share.resumableBase,                                                                                         // 258
    lookup: resumable_post_lookup,                                                                                     // 259
    handler: resumable_post_handler                                                                                    // 260
  }, {                                                                                                                 // 256
    method: 'get',                                                                                                     // 263
    path: share.resumableBase,                                                                                         // 264
    lookup: resumable_get_lookup,                                                                                      // 265
    handler: resumable_get_handler                                                                                     // 266
  }];                                                                                                                  // 262
}                                                                                                                      // 305
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/http_access_server.coffee.js                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var build_access_point, cookieParser, del, dice_multipart, dicer, express, find_mime_boundary, get, grid, gridLocks, handle_auth, lookup_userId_by_token, mongodb, post, put;
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 7
  express = Npm.require('express');                                                                                    // 9
  cookieParser = Npm.require('cookie-parser');                                                                         // 10
  mongodb = Npm.require('mongodb');                                                                                    // 11
  grid = Npm.require('gridfs-locking-stream');                                                                         // 12
  gridLocks = Npm.require('gridfs-locks');                                                                             // 13
  dicer = Npm.require('dicer');                                                                                        // 14
                                                                                                                       //
  find_mime_boundary = function (req) {                                                                                // 16
    var RE_BOUNDARY, result;                                                                                           // 17
    RE_BOUNDARY = /^multipart\/.+?(?:; boundary=(?:(?:"(.+)")|(?:([^\s]+))))$/i;                                       // 17
    result = RE_BOUNDARY.exec(req.headers['content-type']);                                                            // 18
    return (result != null ? result[1] : void 0) || (result != null ? result[2] : void 0);                             // 14
  };                                                                                                                   // 16
                                                                                                                       //
  dice_multipart = function (req, res, next) {                                                                         // 22
    var boundary, count, d, fileName, fileStream, fileType, handleFailure, params, responseSent;                       // 24
    next = share.bind_env(next);                                                                                       // 24
                                                                                                                       //
    if (!(req.method === 'POST' && !req.diced)) {                                                                      // 26
      next();                                                                                                          // 27
      return;                                                                                                          // 28
    }                                                                                                                  // 22
                                                                                                                       //
    req.diced = true;                                                                                                  // 30
    responseSent = false;                                                                                              // 32
                                                                                                                       //
    handleFailure = function (msg, err, retCode) {                                                                     // 33
      if (err == null) {                                                                                               // 26
        err = "";                                                                                                      // 33
      }                                                                                                                // 28
                                                                                                                       //
      if (retCode == null) {                                                                                           // 29
        retCode = 500;                                                                                                 // 33
      }                                                                                                                // 31
                                                                                                                       //
      console.error(msg + " \n", err);                                                                                 // 34
                                                                                                                       //
      if (!responseSent) {                                                                                             // 35
        responseSent = true;                                                                                           // 36
        res.writeHead(retCode, share.defaultResponseHeaders);                                                          // 37
        return res.end();                                                                                              // 36
      }                                                                                                                // 37
    };                                                                                                                 // 33
                                                                                                                       //
    boundary = find_mime_boundary(req);                                                                                // 40
                                                                                                                       //
    if (!boundary) {                                                                                                   // 42
      handleFailure("No MIME multipart boundary found for dicer");                                                     // 43
      return;                                                                                                          // 44
    }                                                                                                                  // 43
                                                                                                                       //
    params = {};                                                                                                       // 46
    count = 0;                                                                                                         // 47
    fileStream = null;                                                                                                 // 48
    fileType = 'text/plain';                                                                                           // 49
    fileName = 'blob';                                                                                                 // 50
    d = new dicer({                                                                                                    // 52
      boundary: boundary                                                                                               // 52
    });                                                                                                                // 52
    d.on('part', function (p) {                                                                                        // 54
      p.on('header', function (header) {                                                                               // 55
        var RE_FILE, RE_PARAM, data, k, param, re, ref, v;                                                             // 56
        RE_FILE = /^form-data; name="file"; filename="([^"]+)"/;                                                       // 56
        RE_PARAM = /^form-data; name="([^"]+)"/;                                                                       // 57
                                                                                                                       //
        for (k in meteorBabelHelpers.sanitizeForInObject(header)) {                                                    // 58
          v = header[k];                                                                                               // 58
                                                                                                                       //
          if (k === 'content-type') {                                                                                  // 59
            fileType = v;                                                                                              // 60
          }                                                                                                            // 61
                                                                                                                       //
          if (k === 'content-disposition') {                                                                           // 61
            if (re = RE_FILE.exec(v)) {                                                                                // 62
              fileStream = p;                                                                                          // 63
              fileName = re[1];                                                                                        // 64
            } else if (param = (ref = RE_PARAM.exec(v)) != null ? ref[1] : void 0) {                                   // 62
              data = '';                                                                                               // 66
              count++;                                                                                                 // 67
              p.on('data', function (d) {                                                                              // 68
                return data += d.toString();                                                                           // 70
              });                                                                                                      // 68
              p.on('end', function () {                                                                                // 70
                count--;                                                                                               // 71
                params[param] = data;                                                                                  // 72
                                                                                                                       //
                if (count === 0 && fileStream) {                                                                       // 73
                  req.multipart = {                                                                                    // 74
                    fileStream: fileStream,                                                                            // 75
                    fileName: fileName,                                                                                // 76
                    fileType: fileType,                                                                                // 77
                    params: params                                                                                     // 78
                  };                                                                                                   // 75
                  responseSent = true;                                                                                 // 79
                  return next();                                                                                       // 83
                }                                                                                                      // 84
              });                                                                                                      // 70
            } else {                                                                                                   // 65
              console.warn("Dicer part", v);                                                                           // 82
            }                                                                                                          // 61
          }                                                                                                            // 89
        }                                                                                                              // 58
                                                                                                                       //
        if (count === 0 && fileStream) {                                                                               // 84
          req.multipart = {                                                                                            // 85
            fileStream: fileStream,                                                                                    // 86
            fileName: fileName,                                                                                        // 87
            fileType: fileType,                                                                                        // 88
            params: params                                                                                             // 89
          };                                                                                                           // 86
          responseSent = true;                                                                                         // 90
          return next();                                                                                               // 99
        }                                                                                                              // 100
      });                                                                                                              // 55
      return p.on('error', function (err) {                                                                            // 102
        return handleFailure('Error in Dicer while parsing multipart:', err);                                          // 103
      });                                                                                                              // 93
    });                                                                                                                // 54
    d.on('error', function (err) {                                                                                     // 96
      return handleFailure('Error in Dicer while parsing parts:', err);                                                // 107
    });                                                                                                                // 96
    d.on('finish', function () {                                                                                       // 99
      if (!fileStream) {                                                                                               // 100
        return handleFailure("Error in Dicer, no file found in POST");                                                 // 111
      }                                                                                                                // 112
    });                                                                                                                // 99
    return req.pipe(d);                                                                                                // 114
  };                                                                                                                   // 22
                                                                                                                       //
  post = function (req, res, next) {                                                                                   // 111
    var stream;                                                                                                        // 113
                                                                                                                       //
    if (req.multipart.fileType) {                                                                                      // 113
      req.gridFS.contentType = req.multipart.fileType;                                                                 // 113
    }                                                                                                                  // 120
                                                                                                                       //
    if (req.multipart.fileName) {                                                                                      // 114
      req.gridFS.filename = req.multipart.fileName;                                                                    // 114
    }                                                                                                                  // 123
                                                                                                                       //
    stream = this.upsertStream(req.gridFS);                                                                            // 117
                                                                                                                       //
    if (stream) {                                                                                                      // 118
      return req.multipart.fileStream.pipe(share.streamChunker(this.chunkSize)).pipe(stream).on('close', function (retFile) {
        if (retFile) {                                                                                                 // 121
          res.writeHead(200, share.defaultResponseHeaders);                                                            // 122
          return res.end();                                                                                            // 129
        }                                                                                                              // 130
      }).on('error', function (err) {                                                                                  // 119
        res.writeHead(500, share.defaultResponseHeaders);                                                              // 125
        return res.end();                                                                                              // 133
      });                                                                                                              // 119
    } else {                                                                                                           // 118
      res.writeHead(410, share.defaultResponseHeaders);                                                                // 128
      return res.end();                                                                                                // 137
    }                                                                                                                  // 138
  };                                                                                                                   // 111
                                                                                                                       //
  get = function (req, res, next) {                                                                                    // 135
    var chunksize, end, filename, h, headers, parts, ref, ref1, since, start, statusCode, stream, v;                   // 137
    headers = {};                                                                                                      // 137
    ref = share.defaultResponseHeaders;                                                                                // 138
                                                                                                                       //
    for (h in meteorBabelHelpers.sanitizeForInObject(ref)) {                                                           // 138
      v = ref[h];                                                                                                      // 145
      headers[h] = v;                                                                                                  // 139
    }                                                                                                                  // 138
                                                                                                                       //
    if (req.headers['if-modified-since']) {                                                                            // 145
      since = Date.parse(req.headers['if-modified-since']);                                                            // 146
                                                                                                                       //
      if (since && req.gridFS.uploadDate && (req.headers['if-modified-since'] === req.gridFS.uploadDate.toUTCString() || since >= req.gridFS.uploadDate.getTime())) {
        res.writeHead(304, headers);                                                                                   // 148
        res.end();                                                                                                     // 149
        return;                                                                                                        // 150
      }                                                                                                                // 145
    }                                                                                                                  // 155
                                                                                                                       //
    if (req.headers['range']) {                                                                                        // 153
      statusCode = 206;                                                                                                // 155
      parts = req.headers["range"].replace(/bytes=/, "").split("-");                                                   // 158
      start = parseInt(parts[0], 10);                                                                                  // 159
      end = parts[1] ? parseInt(parts[1], 10) : req.gridFS.length - 1;                                                 // 160
                                                                                                                       //
      if (start < 0 || end >= req.gridFS.length || start > end || isNaN(start) || isNaN(end)) {                        // 163
        headers['Content-Range'] = 'bytes ' + '*/' + req.gridFS.length;                                                // 164
        res.writeHead(416, headers);                                                                                   // 165
        res.end();                                                                                                     // 166
        return;                                                                                                        // 167
      }                                                                                                                // 166
                                                                                                                       //
      chunksize = end - start + 1;                                                                                     // 170
      headers['Content-Range'] = 'bytes ' + start + '-' + end + '/' + req.gridFS.length;                               // 173
      headers['Accept-Ranges'] = 'bytes';                                                                              // 174
      headers['Content-Type'] = req.gridFS.contentType;                                                                // 175
      headers['Content-Length'] = chunksize;                                                                           // 176
      headers['Last-Modified'] = req.gridFS.uploadDate.toUTCString();                                                  // 177
                                                                                                                       //
      if (req.method !== 'HEAD') {                                                                                     // 180
        stream = this.findOneStream({                                                                                  // 181
          _id: req.gridFS._id                                                                                          // 182
        }, {                                                                                                           // 182
          range: {                                                                                                     // 184
            start: start,                                                                                              // 185
            end: end                                                                                                   // 186
          }                                                                                                            // 185
        });                                                                                                            // 184
      }                                                                                                                // 153
    } else {                                                                                                           // 153
      statusCode = 200;                                                                                                // 192
      headers['Content-Type'] = req.gridFS.contentType;                                                                // 195
      headers['Content-MD5'] = req.gridFS.md5;                                                                         // 196
      headers['Content-Length'] = req.gridFS.length;                                                                   // 197
      headers['Last-Modified'] = req.gridFS.uploadDate.toUTCString();                                                  // 198
                                                                                                                       //
      if (req.method !== 'HEAD') {                                                                                     // 201
        stream = this.findOneStream({                                                                                  // 202
          _id: req.gridFS._id                                                                                          // 202
        });                                                                                                            // 202
      }                                                                                                                // 153
    }                                                                                                                  // 194
                                                                                                                       //
    if (req.query.download && req.query.download.toLowerCase() === 'true' || req.query.filename) {                     // 205
      filename = encodeURIComponent((ref1 = req.query.filename) != null ? ref1 : req.gridFS.filename);                 // 206
      headers['Content-Disposition'] = "attachment; filename=\"" + filename + "\"; filename*=UTF-8''" + filename;      // 207
    }                                                                                                                  // 198
                                                                                                                       //
    if (req.query.cache && !isNaN(parseInt(req.query.cache))) {                                                        // 210
      headers['Cache-Control'] = "max-age=" + parseInt(req.query.cache) + ", private";                                 // 211
    }                                                                                                                  // 201
                                                                                                                       //
    if (req.method === 'HEAD') {                                                                                       // 214
      res.writeHead(204, headers);                                                                                     // 215
      res.end();                                                                                                       // 216
      return;                                                                                                          // 217
    }                                                                                                                  // 206
                                                                                                                       //
    if (stream) {                                                                                                      // 220
      res.writeHead(statusCode, headers);                                                                              // 221
      return stream.pipe(res).on('close', function () {                                                                // 209
        return res.end();                                                                                              // 210
      }).on('error', function (err) {                                                                                  // 222
        res.writeHead(500, share.defaultResponseHeaders);                                                              // 226
        return res.end(err);                                                                                           // 213
      });                                                                                                              // 222
    } else {                                                                                                           // 220
      res.writeHead(410, share.defaultResponseHeaders);                                                                // 229
      return res.end();                                                                                                // 217
    }                                                                                                                  // 218
  };                                                                                                                   // 135
                                                                                                                       //
  put = function (req, res, next) {                                                                                    // 238
    var stream;                                                                                                        // 241
                                                                                                                       //
    if (req.headers['content-type']) {                                                                                 // 241
      req.gridFS.contentType = req.headers['content-type'];                                                            // 242
    }                                                                                                                  // 224
                                                                                                                       //
    stream = this.upsertStream(req.gridFS);                                                                            // 245
                                                                                                                       //
    if (stream) {                                                                                                      // 246
      return req.pipe(share.streamChunker(this.chunkSize)).pipe(stream).on('close', function (retFile) {               // 227
        if (retFile) {                                                                                                 // 249
          res.writeHead(200, share.defaultResponseHeaders);                                                            // 250
          return res.end();                                                                                            // 230
        } else {}                                                                                                      // 249
      }).on('error', function (err) {                                                                                  // 247
        res.writeHead(500, share.defaultResponseHeaders);                                                              // 254
        return res.end(err);                                                                                           // 236
      });                                                                                                              // 247
    } else {                                                                                                           // 246
      res.writeHead(404, share.defaultResponseHeaders);                                                                // 257
      return res.end(req.url + " Not found!");                                                                         // 240
    }                                                                                                                  // 241
  };                                                                                                                   // 238
                                                                                                                       //
  del = function (req, res, next) {                                                                                    // 266
    this.remove(req.gridFS);                                                                                           // 268
    res.writeHead(204, share.defaultResponseHeaders);                                                                  // 269
    return res.end();                                                                                                  // 246
  };                                                                                                                   // 266
                                                                                                                       //
  build_access_point = function (http) {                                                                               // 275
    var i, len, r;                                                                                                     // 278
                                                                                                                       //
    for (i = 0, len = http.length; i < len; i++) {                                                                     // 278
      r = http[i];                                                                                                     // 251
                                                                                                                       //
      if (r.method.toUpperCase() === 'POST') {                                                                         // 280
        this.router.post(r.path, dice_multipart);                                                                      // 281
      }                                                                                                                // 254
                                                                                                                       //
      this.router[r.method](r.path, function (_this) {                                                                 // 284
        return function (r) {                                                                                          // 256
          return function (req, res, next) {                                                                           // 257
            var lookup, opts, ref, ref1, ref2;                                                                         // 289
                                                                                                                       //
            if (((ref = req.params) != null ? ref._id : void 0) != null) {                                             // 289
              req.params._id = share.safeObjectID(req.params._id);                                                     // 289
            }                                                                                                          // 261
                                                                                                                       //
            if (((ref1 = req.query) != null ? ref1._id : void 0) != null) {                                            // 290
              req.query._id = share.safeObjectID(req.query._id);                                                       // 290
            }                                                                                                          // 264
                                                                                                                       //
            lookup = (ref2 = r.lookup) != null ? ref2.bind(_this)(req.params || {}, req.query || {}, req.multipart) : void 0;
                                                                                                                       //
            if (lookup == null) {                                                                                      // 294
              res.writeHead(500, share.defaultResponseHeaders);                                                        // 296
              res.end();                                                                                               // 297
            } else {                                                                                                   // 294
              req.gridFS = _this.findOne(lookup);                                                                      // 301
                                                                                                                       //
              if (!req.gridFS) {                                                                                       // 302
                res.writeHead(404, share.defaultResponseHeaders);                                                      // 303
                res.end();                                                                                             // 304
                return;                                                                                                // 305
              }                                                                                                        // 275
                                                                                                                       //
              switch (req.method) {                                                                                    // 308
                case 'HEAD':                                                                                           // 308
                case 'GET':                                                                                            // 308
                  if (!share.check_allow_deny.bind(_this)('read', req.meteorUserId, req.gridFS)) {                     // 310
                    res.writeHead(403, share.defaultResponseHeaders);                                                  // 311
                    res.end();                                                                                         // 312
                    return;                                                                                            // 313
                  }                                                                                                    // 283
                                                                                                                       //
                  break;                                                                                               // 309
                                                                                                                       //
                case 'POST':                                                                                           // 308
                case 'PUT':                                                                                            // 308
                  req.maxUploadSize = _this.maxUploadSize;                                                             // 315
                                                                                                                       //
                  if (!(opts = share.check_allow_deny.bind(_this)('write', req.meteorUserId, req.gridFS))) {           // 316
                    res.writeHead(403, share.defaultResponseHeaders);                                                  // 317
                    res.end();                                                                                         // 318
                    return;                                                                                            // 319
                  }                                                                                                    // 292
                                                                                                                       //
                  if (opts.maxUploadSize != null && typeof opts.maxUploadSize === 'number') {                          // 320
                    req.maxUploadSize = opts.maxUploadSize;                                                            // 321
                  }                                                                                                    // 295
                                                                                                                       //
                  if (req.maxUploadSize > 0) {                                                                         // 322
                    if (req.headers['content-length'] == null) {                                                       // 323
                      res.writeHead(411, share.defaultResponseHeaders);                                                // 324
                      res.end();                                                                                       // 325
                      return;                                                                                          // 326
                    }                                                                                                  // 301
                                                                                                                       //
                    if (!(parseInt(req.headers['content-length']) <= req.maxUploadSize)) {                             // 327
                      res.writeHead(413, share.defaultResponseHeaders);                                                // 328
                      res.end();                                                                                       // 329
                      return;                                                                                          // 330
                    }                                                                                                  // 322
                  }                                                                                                    // 307
                                                                                                                       //
                  break;                                                                                               // 314
                                                                                                                       //
                case 'DELETE':                                                                                         // 308
                  if (!share.check_allow_deny.bind(_this)('remove', req.meteorUserId, req.gridFS)) {                   // 332
                    res.writeHead(403, share.defaultResponseHeaders);                                                  // 333
                    res.end();                                                                                         // 334
                    return;                                                                                            // 335
                  }                                                                                                    // 314
                                                                                                                       //
                  break;                                                                                               // 331
                                                                                                                       //
                case 'OPTIONS':                                                                                        // 308
                  if (!(share.check_allow_deny.bind(_this)('read', req.meteorUserId, req.gridFS) || share.check_allow_deny.bind(_this)('write', req.meteorUserId, req.gridFS) || share.check_allow_deny.bind(_this)('remove', req.meteorUserId, req.gridFS))) {
                    res.writeHead(403, share.defaultResponseHeaders);                                                  // 340
                    res.end();                                                                                         // 341
                    return;                                                                                            // 342
                  }                                                                                                    // 321
                                                                                                                       //
                  break;                                                                                               // 336
                                                                                                                       //
                default:                                                                                               // 308
                  res.writeHead(500, share.defaultResponseHeaders);                                                    // 344
                  res.end();                                                                                           // 345
                  return;                                                                                              // 346
              }                                                                                                        // 308
                                                                                                                       //
              return next();                                                                                           // 328
            }                                                                                                          // 329
          };                                                                                                           // 286
        };                                                                                                             // 284
      }(this)(r));                                                                                                     // 284
                                                                                                                       //
      if (typeof r.handler === 'function') {                                                                           // 351
        this.router[r.method](r.path, r.handler.bind(this));                                                           // 352
      }                                                                                                                // 335
    }                                                                                                                  // 278
                                                                                                                       //
    return this.router.route('/*').all(function (req, res, next) {                                                     // 337
      if (req.gridFS != null) {                                                                                        // 357
        next();                                                                                                        // 358
      } else {                                                                                                         // 357
        res.writeHead(404, share.defaultResponseHeaders);                                                              // 361
        return res.end();                                                                                              // 342
      }                                                                                                                // 343
    }).head(get.bind(this)).get(get.bind(this)).put(put.bind(this)).post(post.bind(this))["delete"](del.bind(this)).all(function (req, res, next) {
      res.writeHead(500, share.defaultResponseHeaders);                                                                // 369
      return res.end();                                                                                                // 346
    });                                                                                                                // 355
  };                                                                                                                   // 275
                                                                                                                       //
  lookup_userId_by_token = function (authToken) {                                                                      // 374
    var ref, userDoc;                                                                                                  // 375
    userDoc = (ref = Meteor.users) != null ? ref.findOne({                                                             // 375
      'services.resume.loginTokens': {                                                                                 // 376
        $elemMatch: {                                                                                                  // 377
          hashedToken: typeof Accounts !== "undefined" && Accounts !== null ? Accounts._hashLoginToken(authToken) : void 0
        }                                                                                                              // 378
      }                                                                                                                // 377
    }) : void 0;                                                                                                       // 376
    return (userDoc != null ? userDoc._id : void 0) || null;                                                           // 379
  };                                                                                                                   // 374
                                                                                                                       //
  handle_auth = function (req, res, next) {                                                                            // 384
    var ref, ref1;                                                                                                     // 385
                                                                                                                       //
    if (req.meteorUserId == null) {                                                                                    // 385
      if (((ref = req.headers) != null ? ref['x-auth-token'] : void 0) != null) {                                      // 387
        req.meteorUserId = lookup_userId_by_token(req.headers['x-auth-token']);                                        // 388
      } else if (((ref1 = req.cookies) != null ? ref1['X-Auth-Token'] : void 0) != null) {                             // 387
        req.meteorUserId = lookup_userId_by_token(req.cookies['X-Auth-Token']);                                        // 391
      } else {                                                                                                         // 390
        req.meteorUserId = null;                                                                                       // 393
      }                                                                                                                // 385
    }                                                                                                                  // 370
                                                                                                                       //
    return next();                                                                                                     // 371
  };                                                                                                                   // 384
                                                                                                                       //
  share.setupHttpAccess = function (options) {                                                                         // 397
    var h, i, len, otherHandlers, r, ref, ref1, resumableHandlers;                                                     // 400
                                                                                                                       //
    if (options.resumable) {                                                                                           // 400
      if (options.http == null) {                                                                                      // 401
        options.http = [];                                                                                             // 401
      }                                                                                                                // 378
                                                                                                                       //
      resumableHandlers = [];                                                                                          // 402
      otherHandlers = [];                                                                                              // 403
      ref = options.http;                                                                                              // 404
                                                                                                                       //
      for (i = 0, len = ref.length; i < len; i++) {                                                                    // 404
        h = ref[i];                                                                                                    // 383
                                                                                                                       //
        if (h.path === share.resumableBase) {                                                                          // 405
          resumableHandlers.push(h);                                                                                   // 406
        } else {                                                                                                       // 405
          otherHandlers.push(h);                                                                                       // 408
        }                                                                                                              // 388
      }                                                                                                                // 404
                                                                                                                       //
      resumableHandlers = resumableHandlers.concat(share.resumablePaths);                                              // 409
      options.http = resumableHandlers.concat(otherHandlers);                                                          // 410
    }                                                                                                                  // 392
                                                                                                                       //
    if (((ref1 = options.http) != null ? ref1.length : void 0) > 0) {                                                  // 413
      r = express.Router();                                                                                            // 414
      r.use(express.query());                                                                                          // 415
      r.use(cookieParser());                                                                                           // 416
      r.use(handle_auth);                                                                                              // 417
      WebApp.rawConnectHandlers.use(this.baseURL, share.bind_env(r));                                                  // 418
      this.router = express.Router();                                                                                  // 421
      build_access_point.bind(this)(options.http, this.router);                                                        // 422
      return WebApp.rawConnectHandlers.use(this.baseURL, share.bind_env(this.router));                                 // 401
    }                                                                                                                  // 402
  };                                                                                                                   // 397
}                                                                                                                      // 404
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['vsivsi:file-collection'] = {}, {
  FileCollection: FileCollection
});

})();

//# sourceMappingURL=vsivsi_file-collection.js.map
