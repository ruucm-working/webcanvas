(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var Logger, TypeScriptCompiler, TypeScript;

var require = meteorInstall({"node_modules":{"meteor":{"barbatus:typescript-compiler":{"logger.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/createClass",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/barbatus_typescript-compiler/logger.js                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _createClass2 = require("babel-runtime/helpers/createClass");                                                     //
                                                                                                                      //
var _createClass3 = _interopRequireDefault(_createClass2);                                                            //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var util = Npm.require('util');                                                                                       // 1
                                                                                                                      //
var Logger_ = function () {                                                                                           //
  function Logger_() {                                                                                                // 4
    (0, _classCallCheck3.default)(this, Logger_);                                                                     // 4
    this.llevel = process.env.TYPESCRIPT_LOG;                                                                         // 5
  }                                                                                                                   // 6
                                                                                                                      //
  Logger_.prototype.newProfiler = function () {                                                                       //
    function newProfiler(name) {                                                                                      //
      var profiler = new Profiler(name);                                                                              // 9
      if (this.isProfile) profiler.start();                                                                           // 10
      return profiler;                                                                                                // 11
    }                                                                                                                 // 12
                                                                                                                      //
    return newProfiler;                                                                                               //
  }();                                                                                                                //
                                                                                                                      //
  Logger_.prototype.log = function () {                                                                               //
    function log(msg) {                                                                                               //
      if (this.llevel >= 1) {                                                                                         // 27
        for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {     // 27
          args[_key - 1] = arguments[_key];                                                                           // 26
        }                                                                                                             // 27
                                                                                                                      //
        console.log.apply(null, [msg].concat(args));                                                                  // 28
      }                                                                                                               // 29
    }                                                                                                                 // 30
                                                                                                                      //
    return log;                                                                                                       //
  }();                                                                                                                //
                                                                                                                      //
  Logger_.prototype.debug = function () {                                                                             //
    function debug(msg) {                                                                                             //
      if (this.isDebug) {                                                                                             // 33
        for (var _len2 = arguments.length, args = Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
          args[_key2 - 1] = arguments[_key2];                                                                         // 32
        }                                                                                                             // 33
                                                                                                                      //
        this.log.apply(this, msg, args);                                                                              // 34
      }                                                                                                               // 35
    }                                                                                                                 // 36
                                                                                                                      //
    return debug;                                                                                                     //
  }();                                                                                                                //
                                                                                                                      //
  Logger_.prototype.assert = function () {                                                                            //
    function assert(msg) {                                                                                            //
      if (this.isAssert) {                                                                                            // 39
        for (var _len3 = arguments.length, args = Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
          args[_key3 - 1] = arguments[_key3];                                                                         // 38
        }                                                                                                             // 39
                                                                                                                      //
        this.log.apply(this, msg, args);                                                                              // 40
      }                                                                                                               // 41
    }                                                                                                                 // 42
                                                                                                                      //
    return assert;                                                                                                    //
  }();                                                                                                                //
                                                                                                                      //
  (0, _createClass3.default)(Logger_, [{                                                                              //
    key: "isDebug",                                                                                                   //
    get: function () {                                                                                                //
      return this.llevel >= 2;                                                                                        // 15
    }                                                                                                                 // 16
  }, {                                                                                                                //
    key: "isProfile",                                                                                                 //
    get: function () {                                                                                                //
      return this.llevel >= 3;                                                                                        // 19
    }                                                                                                                 // 20
  }, {                                                                                                                //
    key: "isAssert",                                                                                                  //
    get: function () {                                                                                                //
      return this.llevel >= 4;                                                                                        // 23
    }                                                                                                                 // 24
  }]);                                                                                                                //
  return Logger_;                                                                                                     //
}();                                                                                                                  //
                                                                                                                      //
;                                                                                                                     // 43
Logger = new Logger_();                                                                                               // 45
                                                                                                                      //
var Profiler = function () {                                                                                          //
  function Profiler(name) {                                                                                           // 48
    (0, _classCallCheck3.default)(this, Profiler);                                                                    // 48
    this.name = name;                                                                                                 // 49
  }                                                                                                                   // 50
                                                                                                                      //
  Profiler.prototype.start = function () {                                                                            //
    function start() {                                                                                                //
      console.log('%s started', this.name);                                                                           // 53
      console.time(util.format('%s time', this.name));                                                                // 54
      this._started = true;                                                                                           // 55
    }                                                                                                                 // 56
                                                                                                                      //
    return start;                                                                                                     //
  }();                                                                                                                //
                                                                                                                      //
  Profiler.prototype.end = function () {                                                                              //
    function end() {                                                                                                  //
      if (this._started) {                                                                                            // 59
        console.timeEnd(util.format('%s time', this.name));                                                           // 60
      }                                                                                                               // 61
    }                                                                                                                 // 62
                                                                                                                      //
    return end;                                                                                                       //
  }();                                                                                                                //
                                                                                                                      //
  return Profiler;                                                                                                    //
}();                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"file-utils.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/barbatus_typescript-compiler/file-utils.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({                                                                                                       // 1
  isBare: function () {                                                                                               // 1
    return isBare;                                                                                                    // 1
  },                                                                                                                  // 1
  isMainConfig: function () {                                                                                         // 1
    return isMainConfig;                                                                                              // 1
  },                                                                                                                  // 1
  isConfig: function () {                                                                                             // 1
    return isConfig;                                                                                                  // 1
  },                                                                                                                  // 1
  isServerConfig: function () {                                                                                       // 1
    return isServerConfig;                                                                                            // 1
  },                                                                                                                  // 1
  isDeclaration: function () {                                                                                        // 1
    return isDeclaration;                                                                                             // 1
  },                                                                                                                  // 1
  isWeb: function () {                                                                                                // 1
    return isWeb;                                                                                                     // 1
  },                                                                                                                  // 1
  getExtendedPath: function () {                                                                                      // 1
    return getExtendedPath;                                                                                           // 1
  },                                                                                                                  // 1
  getES6ModuleName: function () {                                                                                     // 1
    return getES6ModuleName;                                                                                          // 1
  },                                                                                                                  // 1
  WarnMixin: function () {                                                                                            // 1
    return WarnMixin;                                                                                                 // 1
  },                                                                                                                  // 1
  extendFiles: function () {                                                                                          // 1
    return extendFiles;                                                                                               // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
                                                                                                                      //
function isBare(inputFile) {                                                                                          // 2
  var fileOptions = inputFile.getFileOptions();                                                                       // 3
  return fileOptions && fileOptions.bare;                                                                             // 4
}                                                                                                                     // 5
                                                                                                                      //
function isMainConfig(inputFile) {                                                                                    // 8
  if (!isWeb(inputFile)) return false;                                                                                // 9
  var filePath = inputFile.getPathInPackage();                                                                        // 11
  return (/^tsconfig\.json$/.test(filePath)                                                                           // 12
  );                                                                                                                  // 12
}                                                                                                                     // 13
                                                                                                                      //
function isConfig(inputFile) {                                                                                        // 15
  var filePath = inputFile.getPathInPackage();                                                                        // 16
  return (/tsconfig\.json$/.test(filePath)                                                                            // 17
  );                                                                                                                  // 17
}                                                                                                                     // 18
                                                                                                                      //
function isServerConfig(inputFile) {                                                                                  // 21
  if (isWeb(inputFile)) return false;                                                                                 // 22
  var filePath = inputFile.getPathInPackage();                                                                        // 24
  return (/^server\/tsconfig\.json$/.test(filePath)                                                                   // 25
  );                                                                                                                  // 25
}                                                                                                                     // 26
                                                                                                                      //
function isDeclaration(inputFile) {                                                                                   // 29
  return TypeScript.isDeclarationFile(inputFile.getBasename());                                                       // 30
}                                                                                                                     // 31
                                                                                                                      //
function isWeb(inputFile) {                                                                                           // 33
  var arch = inputFile.getArch();                                                                                     // 34
  return (/^web/.test(arch)                                                                                           // 35
  );                                                                                                                  // 35
}                                                                                                                     // 36
                                                                                                                      //
function getExtendedPath(inputFile) {                                                                                 // 39
  var packageName = inputFile.getPackageName();                                                                       // 40
  packageName = packageName ? packageName.replace(':', '_') + '/' : '';                                               // 41
  var inputFilePath = inputFile.getPathInPackage();                                                                   // 43
  return packageName + inputFilePath;                                                                                 // 44
}                                                                                                                     // 45
                                                                                                                      //
function getES6ModuleName(inputFile) {                                                                                // 47
  var extended = getExtendedPath(inputFile);                                                                          // 48
  return TypeScript.removeTsExt(extended);                                                                            // 49
}                                                                                                                     // 50
                                                                                                                      //
var WarnMixin = {                                                                                                     // 52
  warn: function (error) {                                                                                            // 53
    console.log(error.sourcePath + " (" + error.line + ", " + error.column + "): " + error.message);                  // 54
  }                                                                                                                   // 55
};                                                                                                                    // 52
                                                                                                                      //
function extendFiles(inputFiles, fileMixin) {                                                                         // 58
  inputFiles.forEach(function (inputFile) {                                                                           // 59
    return _.defaults(inputFile, fileMixin);                                                                          // 59
  });                                                                                                                 // 59
}                                                                                                                     // 60
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"typescript-compiler.js":["babel-runtime/helpers/classCallCheck","./file-utils","./utils",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/barbatus_typescript-compiler/typescript-compiler.js                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var getExtendedPath = void 0,                                                                                         // 1
    isDeclaration = void 0,                                                                                           // 1
    isConfig = void 0,                                                                                                // 1
    isMainConfig = void 0,                                                                                            // 1
    isServerConfig = void 0,                                                                                          // 1
    isBare = void 0,                                                                                                  // 1
    getES6ModuleName = void 0,                                                                                        // 1
    WarnMixin = void 0,                                                                                               // 1
    extendFiles = void 0,                                                                                             // 1
    isWeb = void 0;                                                                                                   // 1
module.import('./file-utils', {                                                                                       // 1
  "getExtendedPath": function (v) {                                                                                   // 1
    getExtendedPath = v;                                                                                              // 1
  },                                                                                                                  // 1
  "isDeclaration": function (v) {                                                                                     // 1
    isDeclaration = v;                                                                                                // 1
  },                                                                                                                  // 1
  "isConfig": function (v) {                                                                                          // 1
    isConfig = v;                                                                                                     // 1
  },                                                                                                                  // 1
  "isMainConfig": function (v) {                                                                                      // 1
    isMainConfig = v;                                                                                                 // 1
  },                                                                                                                  // 1
  "isServerConfig": function (v) {                                                                                    // 1
    isServerConfig = v;                                                                                               // 1
  },                                                                                                                  // 1
  "isBare": function (v) {                                                                                            // 1
    isBare = v;                                                                                                       // 1
  },                                                                                                                  // 1
  "getES6ModuleName": function (v) {                                                                                  // 1
    getES6ModuleName = v;                                                                                             // 1
  },                                                                                                                  // 1
  "WarnMixin": function (v) {                                                                                         // 1
    WarnMixin = v;                                                                                                    // 1
  },                                                                                                                  // 1
  "extendFiles": function (v) {                                                                                       // 1
    extendFiles = v;                                                                                                  // 1
  },                                                                                                                  // 1
  "isWeb": function (v) {                                                                                             // 1
    isWeb = v;                                                                                                        // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var getShallowHash = void 0;                                                                                          // 1
module.import('./utils', {                                                                                            // 1
  "getShallowHash": function (v) {                                                                                    // 1
    getShallowHash = v;                                                                                               // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
                                                                                                                      //
var async = Npm.require('async');                                                                                     // 1
                                                                                                                      //
var path = Npm.require('path');                                                                                       // 2
                                                                                                                      //
var fs = Npm.require('fs');                                                                                           // 3
                                                                                                                      //
var Future = Npm.require('fibers/future');                                                                            // 4
                                                                                                                      //
var _Npm$require = Npm.require('meteor-typescript'),                                                                  //
    TSBuild = _Npm$require.TSBuild,                                                                                   //
    validateTsConfig = _Npm$require.validateTsConfig,                                                                 //
    getExcludeRegExp = _Npm$require.getExcludeRegExp;                                                                 //
                                                                                                                      //
var _Npm$require2 = Npm.require('crypto'),                                                                            //
    createHash = _Npm$require2.createHash;                                                                            //
                                                                                                                      //
// Default exclude paths.                                                                                             // 31
var defExclude = new RegExp(getExcludeRegExp(['node_modules/**'])); // What to exclude when compiling for the server.
                                                                                                                      //
var exlWebRegExp = new RegExp(getExcludeRegExp(['typings/main/**', 'typings/main.d.ts'])); // What to exclude when compiling for the client.
                                                                                                                      //
var exlMainRegExp = new RegExp(getExcludeRegExp(['typings/browser/**', 'typings/browser.d.ts']));                     // 40
var COMPILER_REGEXP = /(\.d.ts|\.ts|\.tsx|\.tsconfig)$/;                                                              // 43
                                                                                                                      //
TypeScriptCompiler = function () {                                                                                    // 45
  function TypeScriptCompiler(extraOptions, maxParallelism) {                                                         // 46
    (0, _classCallCheck3.default)(this, TypeScriptCompiler);                                                          // 46
    TypeScript.validateExtraOptions(extraOptions);                                                                    // 47
    this.extraOptions = extraOptions;                                                                                 // 49
    this.maxParallelism = maxParallelism || 10;                                                                       // 50
    this.serverOptions = null;                                                                                        // 51
    this.tsconfig = TypeScript.getDefaultOptions();                                                                   // 52
    this.cfgHash = null;                                                                                              // 53
    this.diagHash = new Set();                                                                                        // 54
    this.archSet = new Set();                                                                                         // 55
  }                                                                                                                   // 56
                                                                                                                      //
  TypeScriptCompiler.prototype.getFilesToProcess = function () {                                                      // 45
    function getFilesToProcess(inputFiles) {                                                                          // 45
      var pexclude = Logger.newProfiler('exclude');                                                                   // 59
      inputFiles = this._filterByDefault(inputFiles);                                                                 // 61
                                                                                                                      //
      this._processConfig(inputFiles);                                                                                // 63
                                                                                                                      //
      inputFiles = this._filterByConfig(inputFiles);                                                                  // 65
                                                                                                                      //
      if (inputFiles.length) {                                                                                        // 67
        var arch = inputFiles[0].getArch();                                                                           // 68
        inputFiles = this._filterByArch(inputFiles, arch);                                                            // 69
      }                                                                                                               // 70
                                                                                                                      //
      pexclude.end();                                                                                                 // 72
      return inputFiles;                                                                                              // 74
    }                                                                                                                 // 75
                                                                                                                      //
    return getFilesToProcess;                                                                                         // 45
  }();                                                                                                                // 45
                                                                                                                      //
  TypeScriptCompiler.prototype.getBuildOptions = function () {                                                        // 45
    function getBuildOptions(inputFiles) {                                                                            // 45
      this._processConfig(inputFiles);                                                                                // 78
                                                                                                                      //
      var inputFile = inputFiles[0];                                                                                  // 80
      var compilerOptions = this.tsconfig.compilerOptions; // Make a copy.                                            // 77
                                                                                                                      //
      compilerOptions = Object.assign({}, compilerOptions);                                                           // 83
                                                                                                                      //
      if (!isWeb(inputFile) && this.serverOptions) {                                                                  // 84
        Object.assign(compilerOptions, this.serverOptions);                                                           // 85
      } // Apply extra options.                                                                                       // 86
                                                                                                                      //
                                                                                                                      //
      if (this.extraOptions) {                                                                                        // 89
        Object.assign(compilerOptions, this.extraOptions);                                                            // 90
      }                                                                                                               // 91
                                                                                                                      //
      var arch = inputFile.getArch();                                                                                 // 93
      var _tsconfig = this.tsconfig,                                                                                  // 77
          typings = _tsconfig.typings,                                                                                // 77
          useCache = _tsconfig.useCache;                                                                              // 77
      return {                                                                                                        // 95
        arch: arch,                                                                                                   // 95
        compilerOptions: compilerOptions,                                                                             // 95
        typings: typings,                                                                                             // 95
        useCache: useCache                                                                                            // 95
      };                                                                                                              // 95
    }                                                                                                                 // 96
                                                                                                                      //
    return getBuildOptions;                                                                                           // 45
  }();                                                                                                                // 45
                                                                                                                      //
  TypeScriptCompiler.prototype.processFilesForTarget = function () {                                                  // 45
    function processFilesForTarget(inputFiles, getDepsContent) {                                                      // 45
      var _this = this;                                                                                               // 98
                                                                                                                      //
      extendFiles(inputFiles, WarnMixin);                                                                             // 99
      var options = this.getBuildOptions(inputFiles);                                                                 // 101
      Logger.log('compiler options: %j', options.compilerOptions);                                                    // 102
      inputFiles = this.getFilesToProcess(inputFiles);                                                                // 104
      if (!inputFiles.length) return;                                                                                 // 106
      var pcompile = Logger.newProfiler('compilation');                                                               // 108
      var filePaths = inputFiles.map(function (file) {                                                                // 109
        return getExtendedPath(file);                                                                                 // 109
      });                                                                                                             // 109
      Logger.log('compile files: %s', filePaths);                                                                     // 110
      var pbuild = Logger.newProfiler('tsBuild');                                                                     // 112
                                                                                                                      //
      var defaultGet = this._getContentGetter(inputFiles);                                                            // 113
                                                                                                                      //
      var getContent = function (filePath) {                                                                          // 114
        return getDepsContent && getDepsContent(filePath) || defaultGet(filePath);                                    // 114
      };                                                                                                              // 114
                                                                                                                      //
      var tsBuild = new TSBuild(filePaths, getContent, options);                                                      // 116
      pbuild.end();                                                                                                   // 117
      var pfiles = Logger.newProfiler('tsEmitFiles');                                                                 // 119
      var future = new Future(); // Don't emit typings.                                                               // 120
                                                                                                                      //
      var compileFiles = inputFiles.filter(function (file) {                                                          // 122
        return !isDeclaration(file);                                                                                  // 122
      });                                                                                                             // 122
      var compilerOptions = options.compilerOptions;                                                                  // 98
      async.eachLimit(compileFiles, this.maxParallelism, function (file, done) {                                      // 124
        var co = compilerOptions;                                                                                     // 125
        var filePath = getExtendedPath(file); // Module set none explicitly, don't use ES6 modules.                   // 127
                                                                                                                      //
        var moduleName = co.module === 'none' ? null : getES6ModuleName(file);                                        // 129
        var pemit = Logger.newProfiler('tsEmit');                                                                     // 131
        var result = tsBuild.emit(filePath, moduleName);                                                              // 132
        pemit.end();                                                                                                  // 133
                                                                                                                      //
        var throwSyntax = _this._processDiagnostics(file, result.diagnostics, co);                                    // 135
                                                                                                                      //
        if (!throwSyntax) {                                                                                           // 136
          var _module = compilerOptions.module;                                                                       // 137
                                                                                                                      //
          _this._addJavaScript(file, result, _module === 'none');                                                     // 138
        }                                                                                                             // 139
                                                                                                                      //
        done();                                                                                                       // 141
      }, future.resolver());                                                                                          // 142
      pfiles.end();                                                                                                   // 144
      future.wait();                                                                                                  // 146
      pcompile.end();                                                                                                 // 148
    }                                                                                                                 // 149
                                                                                                                      //
    return processFilesForTarget;                                                                                     // 45
  }();                                                                                                                // 45
                                                                                                                      //
  TypeScriptCompiler.prototype._getContentGetter = function () {                                                      // 45
    function _getContentGetter(inputFiles) {                                                                          // 45
      var filesMap = new Map();                                                                                       // 152
      inputFiles.forEach(function (inputFile, index) {                                                                // 153
        filesMap.set(getExtendedPath(inputFile), index);                                                              // 154
      });                                                                                                             // 155
      return function (filePath) {                                                                                    // 157
        var index = filesMap.get(filePath);                                                                           // 158
                                                                                                                      //
        if (index === undefined) {                                                                                    // 159
          var filePathNoRootSlash = filePath.replace(/^\//, '');                                                      // 160
          index = filesMap.get(filePathNoRootSlash);                                                                  // 161
        }                                                                                                             // 162
                                                                                                                      //
        return index !== undefined ? inputFiles[index].getContentsAsString() : null;                                  // 163
      };                                                                                                              // 165
    }                                                                                                                 // 166
                                                                                                                      //
    return _getContentGetter;                                                                                         // 45
  }();                                                                                                                // 45
                                                                                                                      //
  TypeScriptCompiler.prototype._addJavaScript = function () {                                                         // 45
    function _addJavaScript(inputFile, tsResult, forceBare) {                                                         // 45
      var source = inputFile.getContentsAsString();                                                                   // 169
      var inputPath = inputFile.getPathInPackage();                                                                   // 170
      var outputPath = TypeScript.removeTsExt(inputPath) + '.js';                                                     // 171
      var toBeAdded = {                                                                                               // 172
        sourcePath: inputPath,                                                                                        // 173
        path: outputPath,                                                                                             // 174
        data: tsResult.code,                                                                                          // 175
        hash: tsResult.hash,                                                                                          // 176
        sourceMap: tsResult.sourceMap,                                                                                // 177
        bare: forceBare || isBare(inputFile)                                                                          // 178
      };                                                                                                              // 172
      inputFile.addJavaScript(toBeAdded);                                                                             // 180
    }                                                                                                                 // 181
                                                                                                                      //
    return _addJavaScript;                                                                                            // 45
  }();                                                                                                                // 45
                                                                                                                      //
  TypeScriptCompiler.prototype._processDiagnostics = function () {                                                    // 45
    function _processDiagnostics(inputFile, diagnostics, tsOptions) {                                                 // 45
      var _this2 = this;                                                                                              // 183
                                                                                                                      //
      // Remove duplicated warnings for shared files                                                                  // 184
      // by saving hashes of already shown warnings.                                                                  // 185
      var reduce = function (diagnostic, cb) {                                                                        // 186
        var dob = {                                                                                                   // 187
          message: diagnostic.message,                                                                                // 188
          sourcePath: getExtendedPath(inputFile),                                                                     // 189
          line: diagnostic.line,                                                                                      // 190
          column: diagnostic.column                                                                                   // 191
        };                                                                                                            // 187
        var arch = inputFile.getArch(); // TODO: find out how to get list of architectures.                           // 193
                                                                                                                      //
        _this2.archSet.add(arch);                                                                                     // 195
                                                                                                                      //
        var shown = false;                                                                                            // 197
                                                                                                                      //
        for (var _iterator = _this2.archSet.keys(), _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
          var _ref;                                                                                                   // 198
                                                                                                                      //
          if (_isArray) {                                                                                             // 198
            if (_i >= _iterator.length) break;                                                                        // 198
            _ref = _iterator[_i++];                                                                                   // 198
          } else {                                                                                                    // 198
            _i = _iterator.next();                                                                                    // 198
            if (_i.done) break;                                                                                       // 198
            _ref = _i.value;                                                                                          // 198
          }                                                                                                           // 198
                                                                                                                      //
          var key = _ref;                                                                                             // 198
                                                                                                                      //
          if (key !== arch) {                                                                                         // 199
            dob.arch = key;                                                                                           // 200
                                                                                                                      //
            var _hash = getShallowHash(dob);                                                                          // 201
                                                                                                                      //
            if (_this2.diagHash.has(_hash)) {                                                                         // 202
              shown = true;                                                                                           // 203
              break;                                                                                                  // 203
            }                                                                                                         // 204
          }                                                                                                           // 205
        }                                                                                                             // 206
                                                                                                                      //
        if (!shown) {                                                                                                 // 207
          dob.arch = arch;                                                                                            // 208
          var hash = getShallowHash(dob);                                                                             // 209
                                                                                                                      //
          _this2.diagHash.add(hash);                                                                                  // 210
                                                                                                                      //
          cb(dob);                                                                                                    // 211
        }                                                                                                             // 212
      }; // Always throw syntax errors.                                                                               // 213
                                                                                                                      //
                                                                                                                      //
      var throwSyntax = !!diagnostics.syntacticErrors.length;                                                         // 216
      diagnostics.syntacticErrors.forEach(function (diagnostic) {                                                     // 217
        reduce(diagnostic, function (dob) {                                                                           // 218
          return inputFile.error(dob);                                                                                // 218
        });                                                                                                           // 218
      });                                                                                                             // 219
      var packageName = inputFile.getPackageName();                                                                   // 221
      if (packageName) return throwSyntax; // And log out other errors except package files.                          // 222
                                                                                                                      //
      if (tsOptions && tsOptions.diagnostics) {                                                                       // 225
        diagnostics.semanticErrors.forEach(function (diagnostic) {                                                    // 226
          reduce(diagnostic, function (dob) {                                                                         // 227
            return inputFile.warn(dob);                                                                               // 227
          });                                                                                                         // 227
        });                                                                                                           // 228
      }                                                                                                               // 229
                                                                                                                      //
      return throwSyntax;                                                                                             // 231
    }                                                                                                                 // 232
                                                                                                                      //
    return _processDiagnostics;                                                                                       // 45
  }();                                                                                                                // 45
                                                                                                                      //
  TypeScriptCompiler.prototype._getFileModuleName = function () {                                                     // 45
    function _getFileModuleName(inputFile, options) {                                                                 // 45
      if (options.module === 'none') return null;                                                                     // 235
      return getES6ModuleName(inputFile);                                                                             // 237
    }                                                                                                                 // 238
                                                                                                                      //
    return _getFileModuleName;                                                                                        // 45
  }();                                                                                                                // 45
                                                                                                                      //
  TypeScriptCompiler.prototype._processConfig = function () {                                                         // 45
    function _processConfig(inputFiles) {                                                                             // 45
      for (var _iterator2 = inputFiles, _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
        var _ref2;                                                                                                    // 241
                                                                                                                      //
        if (_isArray2) {                                                                                              // 241
          if (_i2 >= _iterator2.length) break;                                                                        // 241
          _ref2 = _iterator2[_i2++];                                                                                  // 241
        } else {                                                                                                      // 241
          _i2 = _iterator2.next();                                                                                    // 241
          if (_i2.done) break;                                                                                        // 241
          _ref2 = _i2.value;                                                                                          // 241
        }                                                                                                             // 241
                                                                                                                      //
        var inputFile = _ref2;                                                                                        // 241
                                                                                                                      //
        // Parse root config.                                                                                         // 242
        if (isMainConfig(inputFile)) {                                                                                // 243
          var source = inputFile.getContentsAsString();                                                               // 244
          var hash = inputFile.getSourceHash(); // If hashes differ, create new tsconfig.                             // 245
                                                                                                                      //
          if (hash !== this.cfgHash) {                                                                                // 247
            this.tsconfig = this._parseConfig(source);                                                                // 248
            this.cfgHash = hash;                                                                                      // 249
          }                                                                                                           // 250
        } // Parse server config.                                                                                     // 251
        // Take only target and lib values.                                                                           // 254
                                                                                                                      //
                                                                                                                      //
        if (isServerConfig(inputFile)) {                                                                              // 255
          var _source = inputFile.getContentsAsString();                                                              // 256
                                                                                                                      //
          var _parseConfig2 = this._parseConfig(_source),                                                             // 255
              compilerOptions = _parseConfig2.compilerOptions;                                                        // 255
                                                                                                                      //
          if (compilerOptions) {                                                                                      // 258
            var target = compilerOptions.target,                                                                      // 258
                lib = compilerOptions.lib;                                                                            // 258
            this.serverOptions = {                                                                                    // 260
              target: target,                                                                                         // 260
              lib: lib                                                                                                // 260
            };                                                                                                        // 260
          }                                                                                                           // 261
        }                                                                                                             // 262
      }                                                                                                               // 263
    }                                                                                                                 // 264
                                                                                                                      //
    return _processConfig;                                                                                            // 45
  }();                                                                                                                // 45
                                                                                                                      //
  TypeScriptCompiler.prototype._parseConfig = function () {                                                           // 45
    function _parseConfig(cfgContent) {                                                                               // 45
      var tsconfig = null;                                                                                            // 267
                                                                                                                      //
      try {                                                                                                           // 269
        tsconfig = JSON.parse(cfgContent);                                                                            // 270
        validateTsConfig(tsconfig);                                                                                   // 272
      } catch (err) {                                                                                                 // 273
        throw new Error("Format of the tsconfig is invalid: " + err);                                                 // 274
      }                                                                                                               // 275
                                                                                                                      //
      var exclude = tsconfig.exclude || [];                                                                           // 277
                                                                                                                      //
      try {                                                                                                           // 278
        var regExp = getExcludeRegExp(exclude);                                                                       // 279
        tsconfig.exclude = regExp && new RegExp(regExp);                                                              // 280
      } catch (err) {                                                                                                 // 281
        throw new Error("Format of an exclude path is invalid: " + err);                                              // 282
      }                                                                                                               // 283
                                                                                                                      //
      return tsconfig;                                                                                                // 285
    }                                                                                                                 // 286
                                                                                                                      //
    return _parseConfig;                                                                                              // 45
  }();                                                                                                                // 45
                                                                                                                      //
  TypeScriptCompiler.prototype._filterByDefault = function () {                                                       // 45
    function _filterByDefault(inputFiles) {                                                                           // 45
      inputFiles = inputFiles.filter(function (inputFile) {                                                           // 289
        var path = inputFile.getPathInPackage();                                                                      // 290
        return COMPILER_REGEXP.test(path) && !defExclude.test('/' + path);                                            // 291
      });                                                                                                             // 292
      return inputFiles;                                                                                              // 293
    }                                                                                                                 // 294
                                                                                                                      //
    return _filterByDefault;                                                                                          // 45
  }();                                                                                                                // 45
                                                                                                                      //
  TypeScriptCompiler.prototype._filterByConfig = function () {                                                        // 45
    function _filterByConfig(inputFiles) {                                                                            // 45
      var _this3 = this;                                                                                              // 296
                                                                                                                      //
      var resultFiles = inputFiles;                                                                                   // 297
                                                                                                                      //
      if (this.tsconfig.exclude) {                                                                                    // 298
        resultFiles = resultFiles.filter(function (inputFile) {                                                       // 299
          var path = inputFile.getPathInPackage(); // There seems to an issue with getRegularExpressionForWildcard:   // 300
          // result regexp always starts with /.                                                                      // 302
                                                                                                                      //
          return !_this3.tsconfig.exclude.test('/' + path);                                                           // 303
        });                                                                                                           // 304
      }                                                                                                               // 305
                                                                                                                      //
      return resultFiles;                                                                                             // 306
    }                                                                                                                 // 307
                                                                                                                      //
    return _filterByConfig;                                                                                           // 45
  }();                                                                                                                // 45
                                                                                                                      //
  TypeScriptCompiler.prototype._filterByArch = function () {                                                          // 45
    function _filterByArch(inputFiles, arch) {                                                                        // 45
      check(arch, String); /**                                                                                        // 310
                            * Include only typings that current arch needs,                                           //
                            * typings/main is for the server only and                                                 //
                            * typings/browser - for the client.                                                       //
                            */                                                                                        //
      var filterRegExp = /^web/.test(arch) ? exlWebRegExp : exlMainRegExp;                                            // 317
      inputFiles = inputFiles.filter(function (inputFile) {                                                           // 318
        var path = inputFile.getPathInPackage();                                                                      // 319
        return !filterRegExp.test('/' + path);                                                                        // 320
      });                                                                                                             // 321
      return inputFiles;                                                                                              // 323
    }                                                                                                                 // 324
                                                                                                                      //
    return _filterByArch;                                                                                             // 45
  }();                                                                                                                // 45
                                                                                                                      //
  return TypeScriptCompiler;                                                                                          // 45
}();                                                                                                                  // 45
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"typescript.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/barbatus_typescript-compiler/typescript.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var meteorTS = Npm.require('meteor-typescript');                                                                      // 1
                                                                                                                      //
TypeScript = {                                                                                                        // 3
  validateOptions: function (options) {                                                                               // 4
    if (!options) return;                                                                                             // 5
    meteorTS.validateAndConvertOptions(options);                                                                      // 7
  },                                                                                                                  // 8
  // Extra options are the same compiler options                                                                      // 10
  // but passed in the compiler constructor.                                                                          // 11
  validateExtraOptions: function (options) {                                                                          // 12
    if (!options) return;                                                                                             // 13
    meteorTS.validateAndConvertOptions({                                                                              // 15
      compilerOptions: options                                                                                        // 16
    });                                                                                                               // 15
  },                                                                                                                  // 18
  getDefaultOptions: meteorTS.getDefaultOptions,                                                                      // 20
  compile: function (source, options) {                                                                               // 22
    options = options || meteorTS.getDefaultOptions();                                                                // 23
    return meteorTS.compile(source, options);                                                                         // 24
  },                                                                                                                  // 25
  setCacheDir: function (cacheDir) {                                                                                  // 27
    meteorTS.setCacheDir(cacheDir);                                                                                   // 28
  },                                                                                                                  // 29
  isDeclarationFile: function (filePath) {                                                                            // 31
    return (/^.*\.d\.ts$/.test(filePath)                                                                              // 32
    );                                                                                                                // 32
  },                                                                                                                  // 33
  removeTsExt: function (path) {                                                                                      // 35
    return path && path.replace(/(\.tsx|\.ts)$/g, '');                                                                // 36
  }                                                                                                                   // 37
};                                                                                                                    // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/barbatus_typescript-compiler/utils.js                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({                                                                                                       // 1
  getShallowHash: function () {                                                                                       // 1
    return getShallowHash;                                                                                            // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
                                                                                                                      //
var _Npm$require = Npm.require('crypto'),                                                                             //
    createHash = _Npm$require.createHash;                                                                             //
                                                                                                                      //
function getShallowHash(ob) {                                                                                         // 3
  var hash = createHash('sha1');                                                                                      // 4
  var keys = Object.keys(ob);                                                                                         // 5
  keys.sort();                                                                                                        // 6
  keys.forEach(function (key) {                                                                                       // 8
    hash.update(key).update('' + ob[key]);                                                                            // 9
  });                                                                                                                 // 10
  return hash.digest('hex');                                                                                          // 12
}                                                                                                                     // 13
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/barbatus:typescript-compiler/logger.js");
require("./node_modules/meteor/barbatus:typescript-compiler/file-utils.js");
require("./node_modules/meteor/barbatus:typescript-compiler/typescript-compiler.js");
require("./node_modules/meteor/barbatus:typescript-compiler/typescript.js");
require("./node_modules/meteor/barbatus:typescript-compiler/utils.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['barbatus:typescript-compiler'] = {}, {
  TypeScript: TypeScript,
  TypeScriptCompiler: TypeScriptCompiler
});

})();

//# sourceMappingURL=barbatus_typescript-compiler.js.map
