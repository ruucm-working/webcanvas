var require = meteorInstall({"imports":{"api":{"canvas-contents.js":["meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// imports/api/canvas-contents.js                                                  //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
module.export({                                                                    // 1
  CanvasContents: function () {                                                    // 1
    return CanvasContents;                                                         // 1
  }                                                                                // 1
});                                                                                // 1
var Mongo = void 0;                                                                // 1
module.import('meteor/mongo', {                                                    // 1
  "Mongo": function (v) {                                                          // 1
    Mongo = v;                                                                     // 1
  }                                                                                // 1
}, 0);                                                                             // 1
var CanvasContents = new Mongo.Collection('canvascontents');                       // 3
/////////////////////////////////////////////////////////////////////////////////////

}],"my-files.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// imports/api/my-files.js                                                         //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
module.export({                                                                    // 1
	MyFiles: function () {                                                            // 1
		return MyFiles;                                                                  // 1
	}                                                                                 // 1
});                                                                                // 1
var MyFiles = new FileCollection('myFiles', {                                      // 2
	resumable: true,                                                                  // 3
	// Enable built-in resumable.js upload support                                    // 3
	http: [{                                                                          // 4
		method: 'get',                                                                   // 5
		path: '/:md5',                                                                   // 6
		// this will be at route "/gridfs/myFiles/:md5"                                  // 6
		lookup: function (params, query) {                                               // 7
			// uses express style url params                                                // 7
			return {                                                                        // 8
				md5: params.md5                                                                // 8
			}; // a query mapping url to myFiles                                            // 8
		}                                                                                // 9
	}]                                                                                // 5
});                                                                                // 3
/////////////////////////////////////////////////////////////////////////////////////

},"project-contents.js":["meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// imports/api/project-contents.js                                                 //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
module.export({                                                                    // 1
  ProjectContents: function () {                                                   // 1
    return ProjectContents;                                                        // 1
  }                                                                                // 1
});                                                                                // 1
var Mongo = void 0;                                                                // 1
module.import('meteor/mongo', {                                                    // 1
  "Mongo": function (v) {                                                          // 1
    Mongo = v;                                                                     // 1
  }                                                                                // 1
}, 0);                                                                             // 1
var ProjectContents = new Mongo.Collection('projectcontents');                     // 3
/////////////////////////////////////////////////////////////////////////////////////

}],"users-database.js":["meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// imports/api/users-database.js                                                   //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
module.export({                                                                    // 1
  UsersDatabase: function () {                                                     // 1
    return UsersDatabase;                                                          // 1
  }                                                                                // 1
});                                                                                // 1
var Mongo = void 0;                                                                // 1
module.import('meteor/mongo', {                                                    // 1
  "Mongo": function (v) {                                                          // 1
    Mongo = v;                                                                     // 1
  }                                                                                // 1
}, 0);                                                                             // 1
var UsersDatabase = new Mongo.Collection('usersdatabase');                         // 3
/////////////////////////////////////////////////////////////////////////////////////

}],"word-contents.js":["meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// imports/api/word-contents.js                                                    //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
module.export({                                                                    // 1
  WordContents: function () {                                                      // 1
    return WordContents;                                                           // 1
  }                                                                                // 1
});                                                                                // 1
var Mongo = void 0;                                                                // 1
module.import('meteor/mongo', {                                                    // 1
  "Mongo": function (v) {                                                          // 1
    Mongo = v;                                                                     // 1
  }                                                                                // 1
}, 0);                                                                             // 1
var WordContents = new Mongo.Collection('wordcontents');                           // 3
/////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["../imports/api/canvas-contents.js","../imports/api/project-contents.js","../imports/api/word-contents.js","../imports/api/users-database.js","../imports/api/my-files.js","meteor/meteor",function(require){

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// server/main.js                                                                  //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
var canvas_contents_js_1 = require('../imports/api/canvas-contents.js');           // 1
require('../imports/api/project-contents.js');                                     // 2
var word_contents_js_1 = require('../imports/api/word-contents.js');               // 3
var users_database_js_1 = require('../imports/api/users-database.js');             // 4
var my_files_js_1 = require('../imports/api/my-files.js');                         // 5
var meteor_1 = require('meteor/meteor');                                           // 6
meteor_1.Meteor.publish('wordcontents', function () {                              // 8
    return word_contents_js_1.WordContents.find();                                 //
});                                                                                // 10
meteor_1.Meteor.publish('usersdatabase', function () {                             // 11
    return users_database_js_1.UsersDatabase.find();                               //
});                                                                                // 13
meteor_1.Meteor.publish('canvascontents', function () {                            // 14
    return canvas_contents_js_1.CanvasContents.find();                             //
});                                                                                // 16
// Only publish files owned by this userId, and ignore                             // 19
// file chunks being used by Resumable.js for current uploads                      // 20
meteor_1.Meteor.publish('myData', function () {                                    // 21
    // if (clientUserId === this.userId) {                                         //
    return my_files_js_1.MyFiles.find({ 'metadata._Resumable': { $exists: false },
        'metadata.owner': this.userId });                                          //
    //  } else {        // Prevent client race condition:                          //
    // return null;  // This is triggered when publish is rerun with a new         //
    // 			  // userId before client has resubscribed with that userId              //
    //  }                                                                          //
});                                                                                // 30
// Allow rules for security. Should look familiar!                                 // 33
// Without these, no file writes would be allowed                                  // 34
my_files_js_1.MyFiles.allow({                                                      // 35
    // The creator of a file owns it. UserId may be null.                          //
    insert: function (userId, file) {                                              //
        // Assign the proper owner when a file is created                          //
        file.metadata = file.metadata || {};                                       //
        file.metadata.owner = userId;                                              //
        return true;                                                               //
    },                                                                             //
    // Only owners can remove a file                                               //
    remove: function (userId, file) {                                              //
        // Only owners can delete                                                  //
        return (userId === file.metadata.owner);                                   //
    },                                                                             //
    // Only owners can retrieve a file via HTTP GET                                //
    read: function (userId, file) {                                                //
        return (userId === file.metadata.owner);                                   //
    },                                                                             //
    // This rule secures the HTTP REST interfaces' PUT/POST                        //
    // Necessary to support Resumable.js                                           //
    write: function (userId, file, fields) {                                       //
        // Only owners can upload file data                                        //
        return (userId === file.metadata.owner);                                   //
    }                                                                              //
});                                                                                //
//# sourceMappingURL=main.js.map                                                   //
/////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".ts",".scss",".html",".less"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
