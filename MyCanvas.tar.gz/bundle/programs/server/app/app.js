var require = meteorInstall({"imports":{"api":{"canvas-contents.js":["meteor/mongo",function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/canvas-contents.js                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.export({                                                      // 1
  CanvasContents: function () {                                      // 1
    return CanvasContents;                                           // 1
  }                                                                  // 1
});                                                                  // 1
var Mongo = void 0;                                                  // 1
module.import('meteor/mongo', {                                      // 1
  "Mongo": function (v) {                                            // 1
    Mongo = v;                                                       // 1
  }                                                                  // 1
}, 0);                                                               // 1
var CanvasContents = new Mongo.Collection('canvascontents');         // 12
///////////////////////////////////////////////////////////////////////

}],"users-database.js":["meteor/mongo",function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/users-database.js                                     //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.export({                                                      // 1
  UsersDatabase: function () {                                       // 1
    return UsersDatabase;                                            // 1
  }                                                                  // 1
});                                                                  // 1
var Mongo = void 0;                                                  // 1
module.import('meteor/mongo', {                                      // 1
  "Mongo": function (v) {                                            // 1
    Mongo = v;                                                       // 1
  }                                                                  // 1
}, 0);                                                               // 1
var UsersDatabase = new Mongo.Collection('usersdatabase');           // 3
///////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["../imports/api/canvas-contents.js","../imports/api/users-database.js",function(require){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
require('../imports/api/canvas-contents.js');                        // 1
require('../imports/api/users-database.js');                         // 2
//# sourceMappingURL=main.js.map                                     //
///////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".ts",".scss",".html",".less"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
