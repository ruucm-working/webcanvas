var require = meteorInstall({"imports":{"api":{"canvas-contents.js":["meteor/mongo",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////
//                                                                       //
// imports/api/canvas-contents.js                                        //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
                                                                         //
module.export({                                                          // 1
  CanvasContents: function () {                                          // 1
    return CanvasContents;                                               // 1
  }                                                                      // 1
});                                                                      // 1
var Mongo = void 0;                                                      // 1
module.import('meteor/mongo', {                                          // 1
  "Mongo": function (v) {                                                // 1
    Mongo = v;                                                           // 1
  }                                                                      // 1
}, 0);                                                                   // 1
var CanvasContents = new Mongo.Collection('canvascontents');             // 3
///////////////////////////////////////////////////////////////////////////

}],"project-contents.js":["meteor/mongo",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////
//                                                                       //
// imports/api/project-contents.js                                       //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
                                                                         //
module.export({                                                          // 1
  ProjectContents: function () {                                         // 1
    return ProjectContents;                                              // 1
  }                                                                      // 1
});                                                                      // 1
var Mongo = void 0;                                                      // 1
module.import('meteor/mongo', {                                          // 1
  "Mongo": function (v) {                                                // 1
    Mongo = v;                                                           // 1
  }                                                                      // 1
}, 0);                                                                   // 1
var ProjectContents = new Mongo.Collection('projectcontents');           // 3
///////////////////////////////////////////////////////////////////////////

}],"users-database.js":["meteor/mongo",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////
//                                                                       //
// imports/api/users-database.js                                         //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
                                                                         //
module.export({                                                          // 1
  UsersDatabase: function () {                                           // 1
    return UsersDatabase;                                                // 1
  }                                                                      // 1
});                                                                      // 1
var Mongo = void 0;                                                      // 1
module.import('meteor/mongo', {                                          // 1
  "Mongo": function (v) {                                                // 1
    Mongo = v;                                                           // 1
  }                                                                      // 1
}, 0);                                                                   // 1
var UsersDatabase = new Mongo.Collection('usersdatabase');               // 3
///////////////////////////////////////////////////////////////////////////

}],"word-contents.js":["meteor/mongo",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////
//                                                                       //
// imports/api/word-contents.js                                          //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
                                                                         //
module.export({                                                          // 1
  WordContents: function () {                                            // 1
    return WordContents;                                                 // 1
  }                                                                      // 1
});                                                                      // 1
var Mongo = void 0;                                                      // 1
module.import('meteor/mongo', {                                          // 1
  "Mongo": function (v) {                                                // 1
    Mongo = v;                                                           // 1
  }                                                                      // 1
}, 0);                                                                   // 1
var WordContents = new Mongo.Collection('wordcontents');                 // 3
///////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["../imports/api/canvas-contents.js","../imports/api/project-contents.js","../imports/api/word-contents.js","../imports/api/users-database.js","meteor/meteor",function(require){

///////////////////////////////////////////////////////////////////////////
//                                                                       //
// server/main.js                                                        //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
                                                                         //
var canvas_contents_js_1 = require('../imports/api/canvas-contents.js');
require('../imports/api/project-contents.js');                           // 2
var word_contents_js_1 = require('../imports/api/word-contents.js');     // 3
require('../imports/api/users-database.js');                             // 4
var meteor_1 = require('meteor/meteor');                                 // 5
meteor_1.Meteor.publish('wordcontents', function () {                    // 7
    return word_contents_js_1.WordContents.find();                       //
});                                                                      // 9
meteor_1.Meteor.publish('canvascontents', function () {                  // 10
    return canvas_contents_js_1.CanvasContents.find();                   //
});                                                                      // 12
//# sourceMappingURL=main.js.map                                         //
///////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".ts",".scss",".html",".less"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
